﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Entities entObj = new Entities();

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {

            //Displaying customer details whose city is mumbai
            Customers_150930 city = entObj.Customers_150930.Find();
            var result = from p in entObj.Customers_150930
                         where p.City == "Mumbai"
                         select p;
            //if customer city with mumbai is empty
            if (entObj.Customers_150930.Count() == 0)
            {
                //txtName.Text = string.Empty;
                //txtAddress.Text = string.Empty;
                //txtLandmark.Text = string.Empty;
                //txtPin.Text = string.Empty;
                //txtNumber.Text = string.Empty;

                MessageBox.Show("No customers with Id : " + city);
            }
            else
            {
                // txtName.Text = entObj.Customers_150930.FirstOrDefault().Name;
                //txtName.Text = entObj.Customers_150930.FirstOrDefault().Name;
                //txtAddress.Text = entObj.Customers_150930.FirstOrDefault().Address;
                //txtLandmark.Text = entObj.Customers_150930.FirstOrDefault().Landmark;
                //txtPin.Text = entObj.Customers_150930.FirstOrDefault().PinCode;
                //txtNumber.Text = entObj.Customers_150930.FirstOrDefault().Contact_No;

                List<Customers_150930> data = new List<Customers_150930>();

                foreach (var c in result)
                {
                    data.Add(new Customers_150930()
                    {
                        Name = c.Name,
                        Address = c.Address,
                        Landmark = c.Landmark,
                        PinCode = c.PinCode,
                    
                        Contact_No = c.Contact_No
                    });
                }

                dgObj.ItemsSource = data;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        //    string city = txtCity.Text;

            Entities obj = new Entities();

            //All customer
            //var result = obj.Customers;

            var customers = from c in obj.Customers_150930
                            where c.City == "Mumbai"
                            select c;
            dgObj.ItemsSource = customers.ToList();
            obj.SaveChanges();
        }
    }
}
