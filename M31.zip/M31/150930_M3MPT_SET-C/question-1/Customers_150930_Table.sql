﻿create table manju.Customers_150930
(
    [Id]       INT          IDENTITY (1, 1) NOT NULL,
    [Name] VARCHAR (20) NULL,
    [Address]    VARCHAR (20) NULL,
    [Landmark]  varchar(20) NULL,
	[City] varchar(20) Null,
	[PinCode] varchar(20) Null,
	[Contact_No] varchar(20) Null,
	[EmailId] varchar(20) Null,
    PRIMARY KEY CLUSTERED ([Id] ASC)
)

drop table manju.Customers_150930

CREATE PROCEDURE [manju].[SPX_Insert_Customers_150930]
	@pName varchar(20),
	 @pAddress    VARCHAR (20) ,
    @pLandmark  varchar(20) ,
	@pCity varchar(20) ,
	@pPinCode varchar(20) ,
	@pContact_No varchar(20) ,
	@pEmailId varchar(20) 
AS
	insert into Customers_150930(Name,Address,Landmark,City,PinCode,Contact_No,EmailId) 
	values(@pName, @pAddress,@pLandmark,@pCity,@pPinCode,@pContact_No,@pEmailId )
RETURN 0


CREATE PROCEDURE [manju].[SPX_SelectAll_Customers_150930]
AS
	select * from Customers_150930
RETURN 0