﻿using Customer_150930_Entity;
using Customer_150930_Exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_150930_DAL
{
   

    public class CustomerDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public CustomerDAL(string conString)
        {
            //Connected Architecture;

            cn = new SqlConnection(conString);

            //ds = new DataSet();
            //cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);

        }
        public int Insert(Customer cust)
        {
            int no = 0;
            try
            {
                //1.Way of inserting the values;

                // cmd = new SqlCommand
              
                //2.Inserting Values into the Table;

                //3.Inserting using Stored Procedures;

                cmd = new SqlCommand(" [manju].[SPX_Insert_Customers_150930]", cn);
                cmd.Parameters.AddWithValue("@pName", cust.Name);
                cmd.Parameters.AddWithValue("@pAddress", cust.Address);
                cmd.Parameters.AddWithValue("@pLandmark", cust.LandMark);
                cmd.Parameters.AddWithValue("@pPinCode", cust.Pincode);
                cmd.Parameters.AddWithValue("@pContact_No", cust.ContactNo);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                no = cmd.ExecuteNonQuery();

            }
            catch (Exception_Class e)
            {
                throw;

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }

            return no;
        }
        
       //displaying all values into data grid 
        #region SelectAll()
        public IEnumerable<Customer> SelectAll()
        {
          
       
        {
            List<Customer> cust = new List<Customer>();
            try
            {
               
                //cn.Open();
                //dr = cmd.ExecuteReader();

                //Using stored Procedure
                cmd = new SqlCommand
                ("[manju].[SPX_SelectAll_Customers_150930]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Customer c = new Customer();
                        c.Name = dr[0].ToString();
                        c.Address = dr[1].ToString();
                        c.LandMark = dr[2].ToString();
                        c.Pincode = (long)dr[3];
                            c.ContactNo = dr[4].ToString();

                        cust.Add(c);
                    }
                }


            }
            catch (Exception_Class e)
            {
                throw e;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return cust;
        }
        #endregion
 }

        
}
}
