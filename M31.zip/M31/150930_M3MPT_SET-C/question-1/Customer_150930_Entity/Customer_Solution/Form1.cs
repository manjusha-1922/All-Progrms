﻿using Customer_150930_BAL;
using Customer_150930_Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Customer_Solution
{
    public partial class Form1 : Form
    {
       // Product SelectedProduct = new Product();
        Customers_BAL bal = null;
        public Form1()
        {
            InitializeComponent();
            bal = new Customers_BAL(@"Data Source=ndamssql\sqlilearn;Initial Catalog=16MayCHN;User ID=sqluser;Password=sqluser");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
                Customer cust = new Customer();
                cust.Name = txtName.Text;
                cust.Address = txtAddress.Text;
                cust.LandMark = txtLandmark.Text;
                cust.Pincode = int.Parse(txtPincode.Text);
                cust.ContactNo = txtNumber.Text;
                bal.Add(cust);
                dgDisplay.DataSource= bal.GetAll();
             //   this.DataContext = bal.GetAll();
               
                // int val = int.Parse(bal.GetId().ToString());
                MessageBox.Show("Inserted SuccessFully!!!\n" );

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        //Displaying all the values


        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                //Setting Product Id
             //   txtProductId.Text = bal.GetId().ToString();


                dgDisplay.DataSource = bal.GetAll();
             //   this. = bal.GetAll();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
          //button to clear the values
        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                txtName.Text = string.Empty;
                
                txtAddress.Text=string.Empty;
                txtLandmark.Text=string.Empty;
                //txtPincode.Text=int.Parse.Empty;
                txtNumber.Text=string.Empty;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
