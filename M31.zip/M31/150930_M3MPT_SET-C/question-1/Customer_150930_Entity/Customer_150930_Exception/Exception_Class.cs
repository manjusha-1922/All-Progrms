﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_150930_Exception
{
    public class Exception_Class : ApplicationException
    {
        public Exception_Class() { }

        public Exception_Class(string message)
            :base (message)
        { }
    }
}
