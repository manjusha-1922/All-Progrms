﻿using Customer_150930_DAL;
using Customer_150930_Entity;
using Customer_150930_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Customer_150930_BAL
{
    public class Customers_BAL
    {
        CustomerDAL dal = null;
        public Customers_BAL(string conString)
        {
            dal = new CustomerDAL(conString);
        }
        #region ValidateData()
        public bool ValidateData(Customer cust)
        {
            bool validate = true;
            StringBuilder builderObj = new StringBuilder();

            try
            {
                if (cust.Name == string.Empty)
                {
                    builderObj.AppendLine("Customer Name Should be Provided..");
                    validate = false;
                }
                else if (!Regex.IsMatch(cust.Name, @"[A-Za-z ]+"))
                {
                    builderObj.AppendLine("Enter valid Customer Name..");
                    validate = false;
                }
                if (cust.Address == string.Empty)
                {
                    builderObj.AppendLine("Customer address Should be Provided..");
                    validate = false;
                }
                
                if (cust.LandMark == string.Empty)
                {
                    builderObj.AppendLine("Landmark Should be Provided..");
                    validate = false;
                }
                if (cust.City == string.Empty)
                {
                    builderObj.AppendLine("City Should be Provided..");
                    validate = false;
                }

                if (cust.Pincode.ToString() == string.Empty)
                {
                    builderObj.AppendLine("pincode Should be Provided..");
                    validate = false;
                }
                else if (!(cust.Pincode.ToString().Length == 6))
                {
                    validate = false;
                    builderObj.AppendLine("Only 6 digit pincode should be given");
                }

                if (cust.ContactNo == string.Empty)
                {
                    builderObj.AppendLine("Contact Number Should be Provided..");
                    validate = false;
                }

               else if (cust.ContactNo.Length < 10)
                {
                    validate = false;
                    builderObj.AppendLine("Required 10 Digit Contact Number");
                }

                if (cust.EmailId == string.Empty)
                {
                    builderObj.AppendLine("Email Id Should be Provided..");
                    validate = false;
                }



                if (validate == false)
                {
                    throw new Exception_Class(builderObj.ToString());
                }
            }
            catch (Exception_Class ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return validate;
        }

       

        #endregion


        #region Add()
        public int Add(Customer cust)
        {
            int result = 0;
            try
            {
                if (ValidateData(cust))
                {
                    result = dal.Insert(cust);
                }
                else
                    throw new Exception_Class("Invalid Data");

            }
            catch (Exception_Class ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion


        #region GetAll()
        public IEnumerable<Customer> GetAll()
        {

            try
            {
                return dal.SelectAll();
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        #endregion

       

    }
}


