﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity_Library
{
    public class Pharmcy
    {
        public int Id { get; set; }
        public string MadicineName { get; set; }
        public string Manufacturer { get; set; }
        public string Type { get; set; }
        public DateTime ManufactureDate { get; set; }
        public string BatchNo { get; set; }
        public DateTime ExpiryDate { get; set; }
        public decimal Price { get; set; }
    }
}
