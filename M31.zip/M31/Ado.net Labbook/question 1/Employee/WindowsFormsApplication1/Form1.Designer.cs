﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.texempNo = new System.Windows.Forms.TextBox();
            this.tetEmpName = new System.Windows.Forms.TextBox();
            this.texSalary = new System.Windows.Forms.TextBox();
            this.texEmpNoVal = new System.Windows.Forms.TextBox();
            this.texEmpNameVal = new System.Windows.Forms.TextBox();
            this.texEmpSalaryVal = new System.Windows.Forms.TextBox();
            this.butQuery = new System.Windows.Forms.Button();
            this.butNew = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.grpBoxEmpType = new System.Windows.Forms.GroupBox();
            this.radioBtnPayRoll = new System.Windows.Forms.RadioButton();
            this.radioButtonConsultant = new System.Windows.Forms.RadioButton();
            this.grpBoxEmpType.SuspendLayout();
            this.SuspendLayout();
            // 
            // texempNo
            // 
            this.texempNo.Location = new System.Drawing.Point(12, 37);
            this.texempNo.Name = "texempNo";
            this.texempNo.Size = new System.Drawing.Size(100, 20);
            this.texempNo.TabIndex = 0;
            this.texempNo.Text = "Employee No";
            // 
            // tetEmpName
            // 
            this.tetEmpName.Location = new System.Drawing.Point(12, 87);
            this.tetEmpName.Name = "tetEmpName";
            this.tetEmpName.Size = new System.Drawing.Size(100, 20);
            this.tetEmpName.TabIndex = 1;
            this.tetEmpName.Text = "Employee Name";
            // 
            // texSalary
            // 
            this.texSalary.Location = new System.Drawing.Point(12, 129);
            this.texSalary.Name = "texSalary";
            this.texSalary.Size = new System.Drawing.Size(100, 20);
            this.texSalary.TabIndex = 2;
            this.texSalary.Text = "Salary";
            // 
            // texEmpNoVal
            // 
            this.texEmpNoVal.Location = new System.Drawing.Point(160, 37);
            this.texEmpNoVal.Name = "texEmpNoVal";
            this.texEmpNoVal.Size = new System.Drawing.Size(100, 20);
            this.texEmpNoVal.TabIndex = 3;
            // 
            // texEmpNameVal
            // 
            this.texEmpNameVal.Location = new System.Drawing.Point(160, 87);
            this.texEmpNameVal.Name = "texEmpNameVal";
            this.texEmpNameVal.Size = new System.Drawing.Size(100, 20);
            this.texEmpNameVal.TabIndex = 4;
            // 
            // texEmpSalaryVal
            // 
            this.texEmpSalaryVal.Location = new System.Drawing.Point(160, 129);
            this.texEmpSalaryVal.Name = "texEmpSalaryVal";
            this.texEmpSalaryVal.Size = new System.Drawing.Size(100, 20);
            this.texEmpSalaryVal.TabIndex = 5;
            // 
            // butQuery
            // 
            this.butQuery.Location = new System.Drawing.Point(28, 197);
            this.butQuery.Name = "butQuery";
            this.butQuery.Size = new System.Drawing.Size(75, 23);
            this.butQuery.TabIndex = 6;
            this.butQuery.Text = "Query";
            this.butQuery.UseVisualStyleBackColor = true;
            // 
            // butNew
            // 
            this.butNew.Location = new System.Drawing.Point(224, 197);
            this.butNew.Name = "butNew";
            this.butNew.Size = new System.Drawing.Size(75, 23);
            this.butNew.TabIndex = 7;
            this.butNew.Text = "New";
            this.butNew.UseVisualStyleBackColor = true;
            // 
            // butSave
            // 
            this.butSave.Location = new System.Drawing.Point(399, 196);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(75, 23);
            this.butSave.TabIndex = 8;
            this.butSave.Text = "Save";
            this.butSave.UseVisualStyleBackColor = true;
            // 
            // grpBoxEmpType
            // 
            this.grpBoxEmpType.Controls.Add(this.radioButtonConsultant);
            this.grpBoxEmpType.Controls.Add(this.radioBtnPayRoll);
            this.grpBoxEmpType.Location = new System.Drawing.Point(339, 49);
            this.grpBoxEmpType.Name = "grpBoxEmpType";
            this.grpBoxEmpType.Size = new System.Drawing.Size(200, 100);
            this.grpBoxEmpType.TabIndex = 9;
            this.grpBoxEmpType.TabStop = false;
            this.grpBoxEmpType.Text = "Employee Type";
            // 
            // radioBtnPayRoll
            // 
            this.radioBtnPayRoll.AutoSize = true;
            this.radioBtnPayRoll.Location = new System.Drawing.Point(29, 38);
            this.radioBtnPayRoll.Name = "radioBtnPayRoll";
            this.radioBtnPayRoll.Size = new System.Drawing.Size(61, 17);
            this.radioBtnPayRoll.TabIndex = 0;
            this.radioBtnPayRoll.TabStop = true;
            this.radioBtnPayRoll.Text = "PayRoll";
            this.radioBtnPayRoll.UseVisualStyleBackColor = true;
            // 
            // radioButtonConsultant
            // 
            this.radioButtonConsultant.AutoSize = true;
            this.radioButtonConsultant.Location = new System.Drawing.Point(29, 62);
            this.radioButtonConsultant.Name = "radioButtonConsultant";
            this.radioButtonConsultant.Size = new System.Drawing.Size(75, 17);
            this.radioButtonConsultant.TabIndex = 1;
            this.radioButtonConsultant.TabStop = true;
            this.radioButtonConsultant.Text = "Consultant";
            this.radioButtonConsultant.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 262);
            this.Controls.Add(this.grpBoxEmpType);
            this.Controls.Add(this.butSave);
            this.Controls.Add(this.butNew);
            this.Controls.Add(this.butQuery);
            this.Controls.Add(this.texEmpSalaryVal);
            this.Controls.Add(this.texEmpNameVal);
            this.Controls.Add(this.texEmpNoVal);
            this.Controls.Add(this.texSalary);
            this.Controls.Add(this.tetEmpName);
            this.Controls.Add(this.texempNo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grpBoxEmpType.ResumeLayout(false);
            this.grpBoxEmpType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox texempNo;
        private System.Windows.Forms.TextBox tetEmpName;
        private System.Windows.Forms.TextBox texSalary;
        private System.Windows.Forms.TextBox texEmpNoVal;
        private System.Windows.Forms.TextBox texEmpNameVal;
        private System.Windows.Forms.TextBox texEmpSalaryVal;
        private System.Windows.Forms.Button butQuery;
        private System.Windows.Forms.Button butNew;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.GroupBox grpBoxEmpType;
        private System.Windows.Forms.RadioButton radioButtonConsultant;
        private System.Windows.Forms.RadioButton radioBtnPayRoll;
    }
}

