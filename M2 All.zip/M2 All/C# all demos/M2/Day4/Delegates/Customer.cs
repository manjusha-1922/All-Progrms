﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Delegates
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
    }

    public class CustomerCollection
    {
        List<Customer> custList;
        public List<Customer> GetcustDetails()
        {

            custList = new List<Customer>();
            Customer c1 = new Customer() { CustomerId = 101, CustomerName = "ABC" };
            Customer c2 = new Customer() { CustomerId = 102, CustomerName = "XYZ" };
            custList.Add(c1);
            custList.Add(c2);
            return custList;

        }

        public List<Customer> CollectionInitializer()
        {

            custList = new List<Customer>
            {
                new Customer {CustomerId=103,CustomerName="ARUN"},
                new Customer{CustomerId=104,CustomerName="SHARAN"}

            };

            return custList;

        }
    }
}
