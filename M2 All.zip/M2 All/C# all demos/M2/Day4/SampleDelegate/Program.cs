﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegates;
namespace SampleDelegate
{
    //Creating  delegates
    public delegate int CalcHandler(int a, int b);
    public delegate void MathHandler(int n1, int n2);
    class Program
    {
        public static void Sum(int a, int b)
        {
            Console.WriteLine("The Sum of {0} and {1} is {2}",a,b,(a+b));
        }
        public static void Diff(int a, int b)
        {
            Console.WriteLine("The Deifference between {0} and {1} is {2}", a, b, (a - b));
        }
        public static void SingleCastDelegate()
        {

            Calculator calcObj = new Calculator();

            // Adding functional refernce to the delegate
            CalcHandler handlerObj = new CalcHandler(calcObj.SumInt);

            //1. Invoking the function through delegate

            Console.WriteLine("Sum: " + handlerObj(12, 13).ToString());

            // Or Invoking the function through delegate

            Console.WriteLine(handlerObj.Invoke(12, 13));

            handlerObj = new CalcHandler(calcObj.Product);
            Console.WriteLine("Product " + handlerObj(12, 12).ToString());
        }

        public static void  MultiCastDelegates()
        {
            MathHandler mathObj = new MathHandler(Sum);
                        mathObj += new MathHandler(Diff);// Multicasting
            Console.WriteLine("Calling both Functions");
            mathObj.Invoke(15, 12);

            mathObj -= new MathHandler(Diff);// Removing the method reference from the delegate
            Console.WriteLine("Calling Sum alone");
            mathObj.Invoke(15, 120);

            
        }

        public static void AnonymousMethods()
        {
            MathHandler mathObj = delegate (int a, int b)
                               { Console.WriteLine("The Sum is " + (a + b)); };

            mathObj.Invoke(23, 22);

            CalcHandler handlerObj = delegate (int a1, int b1)
                                     { return a1 + b1; };

            Console.WriteLine("Sum ="+handlerObj.Invoke(22,23).ToString());

        }

        public static void LambdaExpressions()
        {
            MathHandler mathObj = (a, b) =>
               { Console.WriteLine("The Sum is " + (a + b)); };
            
            mathObj(12, 13);

            CalcHandler handlerObj = (a, b) => { return (a + b); };//Lambda1
            CalcHandler handlerObj1 = (a, b) => a+b; //Lambda2

            Console.WriteLine("Sum using Lambda1: "+ handlerObj.Invoke(12, 12).ToString());
            Console.WriteLine("Sum using Lambda2: " + handlerObj1.Invoke(13, 13).ToString());

        

        }



            static void Main(string[] args)
        {

        //    MultiCastDelegates();
        //    AnonymousMethods();
            LambdaExpressions();


        }
    }
}
