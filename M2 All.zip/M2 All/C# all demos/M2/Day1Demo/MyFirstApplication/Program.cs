﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails;
namespace MyFirstApplication
{
    /// <summary>
    /// Author: CG
    /// Date Of Creation: 9th May 2018
    /// Description: To print Hello World
    /// </summary>
    class SampleClass
    {
        int EmpID;// Declare EmpId as Integer
        string EmpName;
        float EmpSal;
        DateTime DOJ;
        long Phno;
        public void GetDetails()
        {

            Console.WriteLine("Enter Employee ID:");
            EmpID = Convert.ToInt32(Console.ReadLine());
            // EmpID = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name:");
            EmpName = Console.ReadLine();
            Console.WriteLine("Enter Employee Basic:");
            EmpSal = float.Parse (Console.ReadLine());
            Console.WriteLine("Enter Employee Date of Joining:");
            DOJ = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Contact No:");
            Phno = Int64.Parse(Console.ReadLine());
        }

        public void DisplaDetails()
        {
            Console.WriteLine("Employee Named {0} with Employee Id {1} has joined on {2}",EmpName,EmpID,DOJ.ToShortDateString() );
            Console.WriteLine("The Contact Info is {0}",Phno.ToString());
            EmployeeOperations empObj = new EmployeeOperations();
            Console.WriteLine(empObj.CalculateSalary(EmpSal, 10, 40));

        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World !!");
            Console.WriteLine("Current Date : "+ DateTime.Now );
            SampleClass sampleObj = new SampleClass();
            sampleObj.GetDetails();
            sampleObj.DisplaDetails();
            Console.ReadKey();

        }
    }
}
