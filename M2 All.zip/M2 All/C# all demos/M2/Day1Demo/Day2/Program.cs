﻿using OOPSample;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Employee emp1 = new Employee("Sangeetha");
            Employee emp2 = new Employee(123, "Geetha");
            Manager mgr = new Manager();
            Manager mgr1 = new Manager(123,"Ganesh", "LnD");

            Console.WriteLine("Base Class Info");
            Console.WriteLine("EmpId\tEmpName");
            Console.WriteLine("1. {0}\t{1}",emp.EmpId,emp.EmpName);
            Console.WriteLine("2. {0}\t{1}", emp1.EmpId, emp1.EmpName);
            Console.WriteLine("3. {0}\t{1}", emp2.EmpId, emp2.EmpName);

            Console.WriteLine("Derived Class Info");
            Console.WriteLine("EmpId\tEmpName\tDept");
            Console.WriteLine("1. {0}\t{1}\t{2}",mgr.EmpId,mgr.EmpName,mgr.DeptName );
            Console.WriteLine("2. {0}\t{1}\t{2}", mgr1.EmpId, mgr1.EmpName, mgr1.DeptName);


        }
    }
}
