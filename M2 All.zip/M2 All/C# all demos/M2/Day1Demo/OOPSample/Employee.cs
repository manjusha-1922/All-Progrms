﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSample
{
    public class Employee
    {
        public int? EmpId { get; set; }
        public string EmpName { get; set; }

        public Employee()
        {
            EmpId = 100;
            EmpName = "NA";

        }
        public Employee(string name)
        {
            this.EmpName = name;

        }
        public Employee(int id, string name)
        {
            this.EmpId = id;
            this.EmpName = name;

        }
    }
   public class Manager:Employee
    {
        public string DeptName { get; set; }

        public Manager()
        {
            DeptName = "Training";
            EmpId = 10;
            EmpName = "Unknown";
        }
        public Manager(int eId, string eName, string dept):base(eId, eName)
        {
            this.DeptName = dept;

        }
    }
}
