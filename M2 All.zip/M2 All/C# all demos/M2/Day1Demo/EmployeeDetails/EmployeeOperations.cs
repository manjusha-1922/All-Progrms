﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    public class EmployeeOperations
    {
        /// <summary>
        /// Method to calculate the net salary for the given basic
        /// </summary>
        /// <param name="Basic"></param>
        /// <returns></returns>
        public string CalculateSalary(float Basic,int hra,int da)
        {
            double salary = 0.0;
            //calculation...
            double deduction = Basic * 0.12;
            salary = ((Basic * hra / 100) + (Basic * da / 100) + Basic) - deduction;
            return "The Calculated Salary is " + salary.ToString();
        }

    }
}
