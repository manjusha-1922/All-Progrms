﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    /// <summary>
/// Author: CG
/// DOC: 9th May 2018
/// Desc: To perform addition and multiplication operation
/// </summary>
    public class Calculator
    {
        /// <summary>
        /// To calculate sum of 2 integers
        /// </summary>
        /// <param name="number1"></param>
        /// <param name="number2"></param>
        /// <returns></returns>
        public int Sum(int number1, int number2)
        {
            
            return number1 + number2;

        }
        /// <summary>
        /// To calculate product of 2 integers
        /// </summary>
        /// <param name="number1"></param>
        /// <param name="number2"></param>
        /// <returns></returns>
        public int Product(int number1, int number2)
        {
            return number1 * number2;

        }

    }
}
