﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecondApplication
{
    class FunctionParameters
    {

        public static int ValSum(int i ) //i/p
        {
            i = 10;
           
            return i ;
           
        }
        public static int RefSum(ref int i)// i/p or o/p
        {
            i = 10;

            return i;
        }
        public static void myMath(int i, int j,out int sum,out int prod) // o/p
        {
            sum = i + j;
            prod = i * j;
     
        }

        /// <summary>
        /// Method to calculate the total marks
        /// </summary>
        /// <param name="studentId"></param>
        /// <param name="studentName"></param>
        /// <param name="Marks"></param>
        /// <returns>Student Report</returns>
        public  string paramArray(int studentId, string studentName, params int[] Marks)
        {
            int total = 0;
            foreach (int i in Marks)
            {
                total += i;
            }

            return string.Format("The Student with Name {0} possessing ID {1} has scored {2}", studentName,studentId, total.ToString());

        }
        static void Main(string[] args)
        {
            #region ValRefOut
            /*
            int n1 = 100;
            int n2 = 20;
            int sumResult, prodResult;
            Console.WriteLine("Val Method Called");
            Console.WriteLine(ValSum(n1) );//10
            Console.WriteLine(n1);//100

            Console.WriteLine("Ref Method Called");
            Console.WriteLine(RefSum(ref n1));//10
            Console.WriteLine(n1);//10

            Console.WriteLine("Out Method Called");
            myMath(n1, n2, out sumResult, out prodResult);
            //Console.WriteLine();//10
            Console.WriteLine("The Sum is {0}\nThe Product is {1}",sumResult,prodResult);
            
            */
            #endregion

            int sId;
            string sName;
            bool chkId;//
            int[] sMarks = new int[] { 98, 88, 78 };

            Console.Write("Enter the Student Name:");
            sName = Console.ReadLine();

            Console.WriteLine("Enter the Student ID:");
            chkId = Int32.TryParse(Console.ReadLine(), out sId);
            if (!chkId)
                Console.WriteLine("Enter a Valid Input");
            else
            {
                if ((sId <= 100) && (sId >= 500))
                { Console.WriteLine("Invalid Student Id"); }
                else
                {
                    FunctionParameters obj = new FunctionParameters();
                    Console.WriteLine(obj.paramArray(sId, sName, sMarks));
                }
            }
        }

      
    }
}
