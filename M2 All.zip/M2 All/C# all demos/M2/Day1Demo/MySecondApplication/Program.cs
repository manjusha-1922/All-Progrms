﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecondApplication
{
    public struct Employee
    {
      public   int EmpId;
       private string EmpName ;
       public EmployeeType empType;
    }

    public enum EmployeeType
    {
        Contract = 101,
        External =123,
        Internal =154

    };
    class Program
    {

static void Main(string[] args)
        {
           #region enumsample
            /*
            int num = 10;
            char initial = 'C';
            float floatNum = num;//Implicit 
            int num1 = (int)floatNum;//Explicit or Type Casting
            string no = num1.ToString();
            num = Convert.ToInt32( no);//Int32.Parse(no);



            EmployeeType eType;
            eType = EmployeeType.External;//Assigned
            int eCode = (int)eType;
            Console.WriteLine(eType.ToString());//Retrieved
            Console.WriteLine(eCode.ToString());

            int newCode = 154;
            EmployeeType newType = (EmployeeType)newCode;
            Console.WriteLine("New Type {0}",newType.ToString());
            Console.WriteLine("New Code {0}",newCode.ToString());
            Console.ReadKey();
            */
            #endregion 
            

            Employee emp;
            Console.WriteLine("Enter your Emp Code");
            emp.EmpId = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter your Project Code");
            int ProjCode = Int32.Parse(Console.ReadLine());
            emp.empType = (EmployeeType)ProjCode;
            Console.WriteLine("Employee Code \t Project Type");
            Console.WriteLine("{0}\t{1}",emp.EmpId,emp.empType );
            Console.ReadKey();
        }
    }
}
