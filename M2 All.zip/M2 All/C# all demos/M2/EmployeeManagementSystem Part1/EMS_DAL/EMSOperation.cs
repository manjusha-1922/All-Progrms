﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSEnity;
using EMSException;
namespace EMS_DAL
{
    /// <summary>
    /// Author: CG
    /// DOC : 11th May
    /// Class with methods to add and display Employee Details
    /// </summary>
    public class EMSOperation
    {
        //static list to maintain the Employee Details
        static List<Employee> empList = new List<Employee>();
        /// <summary>
        /// To add new employee into the List/Collection
        /// </summary>
        /// <param name="newEmp"></param>
        /// <returns></returns>
        public bool AddEmployeeDAL(Employee newEmp)
        {
            bool isEmpAdded = false;
            try
            {
                empList.Add(newEmp);
                isEmpAdded = true;
            }
            catch (EmployeeException)
            {

                throw;
            }
           
            return isEmpAdded;

        }

        public List<Employee> DisplayEmployeeDAL()
        {
            List<Employee> eList;
            try
            {
               eList   = empList;
                
            }
            catch (EmployeeException)
            {

                throw;
            }
            return eList;

        }
    }
}
