﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSException
{
    /// <summary>
    /// Author: CG
    /// DOC : 11th May
    /// Custome Exception class to handle excpetions in EMS
    /// </summary>
    public class EmployeeException:ApplicationException 
    {
        public EmployeeException():base()
        { }
        public EmployeeException(string exMessage) : base(exMessage)
        { }
        public EmployeeException(string exMessage, Exception innerException) : base(exMessage,innerException)
        { }

    }
}
