﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSEnity;
using EMSException;
using EMS_BLL;
namespace EMP__Presentation
{
    class EmployeePresentation
    {
        static EmployeeValidation objValidation;
        public static void AddEmployee()
        {
            try
            {
                objValidation = new EmployeeValidation();
                Employee empNew = new Employee();
                //Get the input from user
                Console.WriteLine("Enter Employee Id :");
                empNew.EmployeeId = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee Name :");
                empNew.EmployeeName = Console.ReadLine();
                Console.WriteLine("Enter Employee DOJ :");
                empNew.DOJ = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee Designation :");
                empNew.Designation = Console.ReadLine();
                Console.WriteLine("Enter Employee ContactNo :");
                empNew.Contact = Int64.Parse(Console.ReadLine());

                if (objValidation.AddEmployeeBLL(empNew))
                    Console.WriteLine("Employee Record added successfully");

            }
            catch (EmployeeException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        public static void DisplayEmployee()
        {
            try
            {
                objValidation = new EmployeeValidation();
                List<Employee> empList = objValidation.DisplayEmpBLL();
                Console.WriteLine("List of Employees: ");

                foreach (Employee empItem in empList)
                {
                    Console.WriteLine("Employee Name : {0}", empItem.EmployeeName);
                    Console.WriteLine("Employee Id : {0}", empItem.EmployeeId.ToString());
                    Console.WriteLine("Employee DOJ : {0}", empItem.DOJ.ToShortDateString());
                    Console.WriteLine("Employee Grade : {0}", empItem.Designation);
                    Console.WriteLine("Employee Contact : {0}", empItem.Contact.ToString());
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("Employee Management System");
            Console.WriteLine("Press 1 To Add New Employee");
            Console.WriteLine("Press 2 To Display All Employees");
            Console.WriteLine("Press 3 To Exit");
        }
        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice:");
                bool chkChoice;
                
                chkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input "); }
                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        DisplayEmployee();
                        break;
                    case 3:
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 3);

            Console.ReadKey();
         }
    }
}
