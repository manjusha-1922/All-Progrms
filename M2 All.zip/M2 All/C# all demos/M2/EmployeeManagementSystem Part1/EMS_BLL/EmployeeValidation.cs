﻿using EMS_DAL;
using EMSEnity;
using EMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EMS_BLL
{
    /// <summary>
    /// Author: CG
    /// DOC : 15th May
    /// Class that performs Validations and communicates to PL
    /// </summary>
    public class EmployeeValidation
    {
        EMSOperation operationsObj;
        static List<Employee> empList = new List<Employee>();

        public bool ValidateEmployee(Employee newEmployee)
        {
            bool isValidEmployee = true;
            StringBuilder sbEMSError = new StringBuilder();

            if (newEmployee.EmployeeId.ToString().Equals(string.Empty))
            {
                isValidEmployee = false;
                sbEMSError.Append("Employee Id cannot be blank " + Environment.NewLine);

            }
            if (newEmployee.EmployeeId.ToString().Length != 6)
            {
                isValidEmployee = false;
                sbEMSError.Append("Employee Id must be of 6 digits " + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newEmployee.EmployeeName, "[A-Z][a-z]{3,}")))
            {
                isValidEmployee = false;
                sbEMSError.Append("Employee Name must have only characters starting with uppercase " + Environment.NewLine);
            }
            if (newEmployee.DOJ >= DateTime.Now)
            {
                isValidEmployee = false;
                sbEMSError.Append("Employee DOJ must not be a future Date " + Environment.NewLine);

            }
            if (!(Regex.IsMatch(newEmployee.Contact.ToString(), "[6-9][0-9]{9}")))
            {
                isValidEmployee = false;
                sbEMSError.Append("Employee contact should have 10 digits " + Environment.NewLine);
            }

            if (!isValidEmployee)
                { throw new EmployeeException(sbEMSError.ToString()); }

            return isValidEmployee;


        }
        public bool AddEmployeeBLL(Employee newEmployee)
        {
            bool isEmpAdded = false;

            try
            {
                operationsObj = new EMSOperation();
                if (ValidateEmployee(newEmployee))
                    isEmpAdded = operationsObj.AddEmployeeDAL(newEmployee);
                else
                    throw new EmployeeException("Validation Failed!!!Employee Record could not be added");
            }
            catch (EmployeeException)
            {

                throw;
            }
            return isEmpAdded;

        }

        public List<Employee> DisplayEmpBLL()
        {
            try
            {
                operationsObj = new EMSOperation();
                empList = operationsObj.DisplayEmployeeDAL();
                if (empList.Count <= 0)
                {

                    throw new EmployeeException("No Records Found");
                }
            }
            catch (EmployeeException ex)
            {

                throw ex;
            }

            return empList;
        }

    }
}
