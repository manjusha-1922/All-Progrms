﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSEnity;
using EMSException;
using EMS_BLL;
using System.IO;

namespace EMP__Presentation
{
    class EmployeePresentation
    {
        static EmployeeValidation objValidation;
        public static void AddEmployee()
        {
            try
            {
                objValidation = new EmployeeValidation();
                Employee empNew = new Employee();
                //Get the input from user
                Console.WriteLine("Enter Employee Id :");
                empNew.EmployeeId = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee Name :");
                empNew.EmployeeName = Console.ReadLine();
                Console.WriteLine("Enter Employee DOJ :");
                empNew.DOJ = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee Designation :");
                empNew.Designation = Console.ReadLine();
                Console.WriteLine("Enter Employee ContactNo :");
                empNew.Contact = Int64.Parse(Console.ReadLine());

                if (objValidation.AddEmployeeBLL(empNew))
                    Console.WriteLine("Employee Record added successfully");

            }
            catch (EmployeeException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        public static void DisplayEmployee()
        {
            try
            {
                objValidation = new EmployeeValidation();
                List<Employee> empList = objValidation.DisplayEmpBLL();
                Console.WriteLine("List of Employees: ");

                foreach (Employee empItem in empList)
                {
                    Console.WriteLine("Employee Name : {0}", empItem.EmployeeName);
                    Console.WriteLine("Employee Id : {0}", empItem.EmployeeId.ToString());
                    Console.WriteLine("Employee DOJ : {0}", empItem.DOJ.ToShortDateString());
                    Console.WriteLine("Employee Grade : {0}", empItem.Designation);
                    Console.WriteLine("Employee Contact : {0}", empItem.Contact.ToString());
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("============================================");
            Console.WriteLine("Employee Management System Menu");
            Console.WriteLine("Press 1 To Add New Employee");
            Console.WriteLine("Press 2 To Display All Employees");
            Console.WriteLine("Press 3 To Search Employee");
            Console.WriteLine("Press 4 To Delete Employee");
            Console.WriteLine("Press 5 To Update Employee");
            Console.WriteLine("Press 6 To Store Data in File");
            Console.WriteLine("Press 7 To Display Data from File");
            Console.WriteLine("Press 8 To Exit");
            Console.WriteLine("============================================");

        }
        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice:");
                bool chkChoice;

                chkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input "); }
                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        DisplayEmployee();
                        break;
                    case 3:
                        SearchEmployee();
                        break;
                    case 4:
                        DeleteEmployee();
                        break;
                    case 5:
                        UpdateEmployee();
                        break;
                    case 6:
                        SerializeEmployee();
                        break;
                    case 7:
                        DeserializeEmployee();
                        break;
                    case 8:
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 8);

            Console.ReadKey();
        }

        private static void DeserializeEmployee()
        {
            try
            {
             List<Employee> eList=   objValidation.DeserializeEmployeeBLL();
                Console.WriteLine("Records from File: ");
                foreach (Employee emp in eList)
                {
                    Console.WriteLine("Employee Name: {0}", emp.EmployeeName);
                    Console.WriteLine("Employee Designation: {0}", emp.Designation);
                    Console.WriteLine("Employee Contact: {0}", emp.Contact);
                    Console.WriteLine("Employee DOJ : {0}", emp.DOJ.ToShortDateString());
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void SerializeEmployee()
        {
            try
            {
                objValidation.SerializeEmployeeBLL();
                Console.WriteLine("Employee Record stored in File");
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateEmployee()
        {
            Employee emp = new Employee();
            try
            {
                Console.WriteLine("Enter Employee Id to be updated:");
                emp.EmployeeId = Int32.Parse(Console.ReadLine());

                bool isUpdated = objValidation.UpdateEmployeeBLL(emp);
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeleteEmployee()
        {
            
            try
            {
                Console.WriteLine("Enter Employee Id to be deleted:");
                int empId = Int32.Parse(Console.ReadLine());

                bool isDeleted= objValidation.DeleteEmployeeBLL(empId);
                if (isDeleted) Console.WriteLine("Record Deleted!! ");
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchEmployee()
        {
            Employee empSearch = null;
            try
            {
                Console.WriteLine("Enter Employee Id to be searched:");
                int empId = Int32.Parse(Console.ReadLine());

               empSearch= objValidation.SearchEmployeeBLL(empId);
                if (empSearch != null)
                {
                    Console.WriteLine("Searched Employee Details:");
                    Console.WriteLine("Employee Name: {0}",empSearch.EmployeeName );
                    Console.WriteLine("Employee Designation: {0}", empSearch.Designation);
                    Console.WriteLine("Employee Contact: {0}", empSearch.Contact);
                    Console.WriteLine("Employee DOJ : {0}", empSearch.DOJ.ToShortDateString());
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
