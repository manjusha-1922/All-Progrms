﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSEnity;
using EMSException;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace EMS_DAL
{
    /// <summary>
    /// Author: CG
    /// DOC : 11th May
    /// Class with methods to add and display Employee Details
    /// </summary>
    public class EMSOperation
    {
        //static list to maintain the Employee Details
        static List<Employee> empList = new List<Employee>();
        /// <summary>
        /// To add new employee into the List/Collection
        /// </summary>
        /// <param name="newEmp"></param>
        /// <returns></returns>
        public bool AddEmployeeDAL(Employee newEmp)
        {
            bool isEmpAdded = false;
            try
            {
                empList.Add(newEmp);
                isEmpAdded = true;
            }
            catch (EmployeeException)
            {

                throw;
            }
           
            return isEmpAdded;

        }

        public List<Employee> DisplayEmployeeDAL()
        {
            List<Employee> eList;
            try
            {
               eList   = empList;
                
            }
            catch (EmployeeException)
            {

                throw;
            }
            return eList;

        }

        /// <summary>
        /// Delete an Employee record from the Collection based on EmployeeID
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        public bool DeleteEmployeeDAL(int empId)
        {
            bool isEmpDeleted = false;
            Employee empToDelete = new Employee();
            try
            {
                empToDelete = empList.Find(emp => emp.EmployeeId == empId);
               empList.Remove(empToDelete);
                isEmpDeleted = true;
            }

            catch (EmployeeException)
            {
                throw;
            }
            return isEmpDeleted;

        }

        public Employee SearchEmployeeDAL(int empID)
        {
            Employee searchedEmployee;

            try
            {
                searchedEmployee = empList.Find(emp => emp.EmployeeId == empID);

            }
            catch (EmployeeException) { throw; }
            return searchedEmployee;

        }

        public bool UpdateEmployeeDAL(Employee editEmp)
        {
            Employee updatedEmployee;
            bool isEmpUpdated = false;
            try
            {
                updatedEmployee = empList.Find(emp => emp.EmployeeId == editEmp.EmployeeId);
                updatedEmployee.EmployeeName = editEmp.EmployeeName;
                updatedEmployee.DOJ = editEmp.DOJ;
                updatedEmployee.Contact = editEmp.Contact;
                updatedEmployee.Designation = editEmp.Designation;
                isEmpUpdated = true;
            }
            catch (EmployeeException) { throw; }
            return isEmpUpdated;

        }
        public static void SerializeEmployeeDAL()
        {
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("sample.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter binFormatter = new BinaryFormatter();
                binFormatter.Serialize(fStream, empList );
            }
            catch (IOException)
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            finally
            {
                fStream.Close();
            }

        }

        public static List<Employee> DeserializeEmployeeDAL()
        {
           List<Employee> deserializedData = null;
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("sample.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormatter = new BinaryFormatter();
                deserializedData = (List<Employee>)binFormatter.Deserialize(fStream);
            }
            catch (IOException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            finally
            {
                fStream.Close();
            }
            return deserializedData;

        }

    }
}
