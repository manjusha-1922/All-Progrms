﻿using System;
using ArrayLibrary;

namespace UsingLibrary_CUI
{
    class TwoDArrayExample
    {
        static void Main(string[] args)
        {
            int[,] A;
            int[,] B;
           // int[,] C;
            int rows, cols;
            Console.WriteLine("Rows :- ");
            rows = int.Parse(Console.ReadLine());
            Console.WriteLine("Cols :- ");
            cols = int.Parse(Console.ReadLine());

            //Initialization
            A = new int[rows, cols];
            B = new int[rows, cols];
            Console.WriteLine("\n Fill Matrix A with " + rows * cols+"elements");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    A[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("\n Fill Matrix B with "+ rows *cols+"elements");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    B[i, j] = int.Parse(Console.ReadLine());
                }
            }
            
            TwoDArray twoDArrayObj = new TwoDArray();
            twoDArrayObj.GetMatrixAandB(A, B, rows, cols);

            int opt;
            Console.WriteLine("Enter option:");
            opt = int.Parse(Console.ReadLine());
            switch(opt)
            {
                case 1:
                    {
                        Console.WriteLine("Addition");
                        twoDArrayObj.MatrixAddition();
                        twoDArrayObj.display();
                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("Subtraction");
                        twoDArrayObj.MatrixSubtraction();
                        twoDArrayObj.display();
                    }
                    break;
                default:
                    Console.WriteLine("Enter valid input");
                    break;
            }
            
        }
    }
}
