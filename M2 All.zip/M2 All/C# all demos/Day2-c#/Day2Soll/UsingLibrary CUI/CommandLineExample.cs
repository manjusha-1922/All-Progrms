﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingLibrary_CUI
{
    

    class SimpleIntrest
    {


        public static void Main(string[] args)

        {
            float pa = float.Parse(args[0]);

            float roi = float.Parse(args[1]);

            float noy = float.Parse(args[2]);


            float si = (pa * roi * noy) / 100;

            Console.WriteLine("Simple Intrest is" + si);

        }
    }
}
