﻿using System;
using ConstructsLib;

namespace UsingLibrary_CUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter character");
            char letter = char.Parse(Console.ReadLine());
            //or
            //char letter = Convert.ToChar(Console.ReadLine());
            Alphabets alphabetsObj = new Alphabets();
            //calling directly
            //alphabetsObj.GetCharacter(letter);
            //or
            //calling with name of the parameter
            alphabetsObj.GetCharacter(alpha: letter);
            string res = alphabetsObj.CheckLUCase();
            Console.WriteLine("U have entered " + res+" letter");
        }
    }
}
