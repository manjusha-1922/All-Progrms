﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingLibrary_CUI
{
    class AllLoops
    {
        static void Main(string[] args)
        {
            LoopDemo loopsDemoObj = new LoopDemo();
            /*int total = loopsDemoObj.WhileLoopFunc(10);
            Console.WriteLine("sum using while loop : "+total);
            total = loopsDemoObj.DoWhileLoopFunc(10);
            Console.WriteLine("sum using DoWhile loop :"+total);*/
            //total = loopsDemoObj.ForLoopFunc(10);
            //Console.WriteLine("sum For loop :" + total);
            //total = loopsDemoObj.ForLoopFunc(10);
            //Console.WriteLine("sum using do while loop :" + total);

            int[] n = { 1, 2, 3, 4, 6 };

            //int[] n;
        //    total = loopsDemoObj.ForEachLoopFunc(n);
        //    Console.WriteLine("sUM USING fOReACH lOOP :"+total);
        }
    }
}
