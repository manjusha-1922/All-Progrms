﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArrayLibrary;
namespace UsingLibrary_CUI
{
    class OneDArrayExample
    {
        static void Main(string[] args)
        {
            oneDArray oneDArrayObj = new oneDArray();

            Console.WriteLine("Enter size of array :");
            int size = int.Parse(Console.ReadLine());
            int[] numbers = new int[size];
            for (int i = 0; i < size; i++)
                numbers[i] = int.Parse(Console.ReadLine());
            Console.WriteLine("Print All Elements ");
            for(int i=0;i<size;i++)
            {
                Console.WriteLine(numbers[i]+", ");
            }
            oneDArrayObj.Initialize(numbers);
            StringBuilder stringBuilderObj = oneDArrayObj.countEvenOddZeros();
            Console.WriteLine(stringBuilderObj);
        }
    }
}
