﻿using ConstructsLib.Conditional_Constructs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingLibrary_CUI
{
    class ShapeSwitchCase
    {
        static void Main(string[] args)
        {

            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Shapes shapesObj = new Shapes();
            while (true)
            {
                Console.WriteLine("\n\t\t\tMenu :-");
                Console.WriteLine("\t\t\tC - Circle");
                Console.WriteLine("\t\t\tR - Rectangle");
                Console.WriteLine("\t\t\tS - Square");
                Console.WriteLine("\t\t\tT - Triangle");
                Console.WriteLine("\t\t\tE - Exit");

                Console.WriteLine("\n\t\t\tEnter your choice:");
                char choice = Convert.ToChar(Console.ReadLine());
               

                switch (char.ToUpper(choice))
                {
                    case 'C':
                        {
                            Console.WriteLine("\n\t\t\t Calculating Atrea of circle..");
                            Console.WriteLine("\n\t\tRadius :-");
                            float radius = Convert.ToSingle(Console.ReadLine());
                            float area = shapesObj.Circle(radius);
                            Console.WriteLine("\n\t\t\t Atea of circle..." + area);
                        }
                        break;
                    case 'R':
                        {
                            Console.WriteLine("\n\t\t\t Calculating Atrea of Rectangle..");
                            Console.WriteLine("\n\t\tLength :-");
                            float length = Convert.ToSingle(Console.ReadLine());
                            Console.WriteLine("\n\t\tBreadth :-");
                            float breadth = Convert.ToSingle(Console.ReadLine());
                            float area = shapesObj.Rectangle(length, breadth);
                            Console.WriteLine("\n\t\t\t Atea of Rectangle..." + area);
                        }
                        break;
                    case 'T':
                        {
                            Console.WriteLine("\n\t\t\t Calculating Atrea of Triangle..");
                            Console.WriteLine("\n\t\tBase :-");
                            float b = Convert.ToSingle(Console.ReadLine());
                            Console.WriteLine("\n\t\tHeight :-");
                            float h = Convert.ToSingle(Console.ReadLine());
                            float area = shapesObj.Triangle(b, h);
                            Console.WriteLine("\n\t\t\t Atea of Triangle..." + area);
                        }
                        break;
                    case 'S':
                        {
                            Console.WriteLine("\n\t\t\t Calculating Atrea of Square..");

                            Console.WriteLine("\n\t\tSide :-");
                            float s = Convert.ToSingle(Console.ReadLine());
                            float area = shapesObj.Square(s);
                            Console.WriteLine("\n\t\t\t Atea of square..." + area);
                        }
                        break;
                    case 'E':
                        {
                            Console.WriteLine("\n\t\tThank You");
                            // return;
                            Environment.Exit(0);
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("\n\t\t\tInvalid choice, please enter correct choice");
                        }
                        break;
                }
                //to hold the screen
                Console.ReadKey();
                //to clear the screen
                Console.Clear();
            }
        }
    }
}
