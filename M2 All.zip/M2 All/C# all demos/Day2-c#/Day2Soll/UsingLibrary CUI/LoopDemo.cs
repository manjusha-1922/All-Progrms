﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingLibrary_CUI
{
   public class LoopDemo
    {
        //int sum;
        public int WhileLoopFunc(int n)
        {
            int sum = 0;
            int i = 1;
            while(i<n)
            {
                sum += i;
                i++;
            }
            return sum;
        }
     /*   public int ForEachLoopFunc(int []n)
        {
            foreach()
        }*/
    }
}
