﻿using System;
using ArrayLibrary;

namespace UsingLibrary_CUI
{
    class JaggedArrayExample
    {
        static void Main(string[] args)
        {
            JaggedArray.display();
        }
    }
}
