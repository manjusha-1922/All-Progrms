﻿using ArrayLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingLibrary_CUI
{
    class BuiltInArrayExample
    {
        static void Main(string[] args)
        {
            BuiltInArray builtInArrayObj = new BuiltInArray();
            builtInArrayObj.Display();
        }
    }
}
