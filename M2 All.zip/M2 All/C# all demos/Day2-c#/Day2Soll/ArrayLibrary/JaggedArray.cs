﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayLibrary
{
   public class JaggedArray
    {
     static int[][] jagged = new int[4][];

        public static void display()
        {
            jagged[0] = new int[2] { 7, 9 };
            jagged[1] = new int[4] { 2, 4, 26, 38 };
            jagged[2] = new int[6] { 3, 5, 7, 9, 11, 13 };
            jagged[3] = new int[3] { 4, 6, 8 };

            //display elements of jagged array

            for(int i=0;i <jagged.Length; i++)
            {
                Console.WriteLine("Element ({0}): ",i+1);
                for(int j=0;j< jagged[i].Length; j++)
                {
                    Console.WriteLine(jagged[i][j] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}
