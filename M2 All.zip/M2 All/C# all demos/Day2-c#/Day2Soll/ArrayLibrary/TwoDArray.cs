﻿using System;
                                                                                                                                                                                                                                                       
namespace ArrayLibrary
{
   public class TwoDArray
    {
        int[,] A;
        int[,] B;
        int[,] C;
        int rows, cols;

        public void GetMatrixAandB(int [,]A,int [,]B,int rows,int cols)
        {
            this.A = A;
            this.B = B;
            this.rows = rows;
            this.cols = cols;
            C = new int[rows, cols];

        }
        public void MatrixSubtraction()
        {
            for(int i=0;i<rows;i++)
            {
                for(int j=0;j<cols;j++)
                {
                    C[i, j] = A[i, j] - B[i, j];
                }
            }
        }
        public void MatrixAddition()
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    C[i, j] = A[i, j] + B[i, j];
                }
            }
        }
        public void display()
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Console.WriteLine("{0} - {1} = {2}",A[i,j],B[i,j],C[i,j]);
                    Console.WriteLine("{0} + {1} = {2}", A[i, j], B[i, j], C[i, j]);
                }
                Console.WriteLine();
            }
        }

    }
}
