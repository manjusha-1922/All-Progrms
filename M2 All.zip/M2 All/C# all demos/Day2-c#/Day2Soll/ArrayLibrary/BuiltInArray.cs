﻿using System;

namespace ArrayLibrary
{
    public class BuiltInArray
    {
        public void Display()
        {
            int[] numbers = { 10, 2, 0, 5, 1, 4, 8, 6 };
            Console.Write("\nPrint All numbers");
            foreach (int n in numbers)
            {
                Console.Write(n+" ");
            }
            Console.Write("\nPrint All numbers in ascending order :");
            Array.Sort(numbers);
            foreach(int n in numbers)
            {
                Console.Write(n +", ");
            }
            Console.Write("\nPrint All numbers in descending order :");
            Array.Reverse(numbers);
            foreach (int n in numbers)
            {
                Console.WriteLine(n + ", ");
            }
            Console.WriteLine("Total number of elements : " +numbers.Length);
        }
    }
}
