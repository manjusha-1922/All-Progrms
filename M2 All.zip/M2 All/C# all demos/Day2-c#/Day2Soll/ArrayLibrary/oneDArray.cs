﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayLibrary
{
    public class oneDArray
    {
        int[] numbers;
        public void Initialize(int []numbers)
        {
            this.numbers = numbers;
        }
        public StringBuilder countEvenOddZeros()
        {
            int ECnt=0, OCnt=0, ZCnt=0;
            for(int i=0;i<numbers.Length;i++)
            {
                if (numbers[i] == 0)
                    ZCnt++;
                else if (numbers[i] % 2 == 0)
                    ECnt += 1;
                else
                    OCnt = OCnt + 1;

             }
            StringBuilder stringBuilderObj = new StringBuilder();
            stringBuilderObj.Append("Zero Count is " + ZCnt);
            stringBuilderObj.Append("\nEven Count is " + ECnt);
            stringBuilderObj.Append("\nOdd Count is " + OCnt);
            return stringBuilderObj;

        }
    }

}
