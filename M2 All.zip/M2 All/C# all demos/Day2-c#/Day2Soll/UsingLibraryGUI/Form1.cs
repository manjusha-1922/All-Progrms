﻿using ConstructsLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UsingLibraryGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            char letter = char.Parse(txtAlpha.Text);
            
            Alphabets alphabetsObj = new Alphabets();
            
            alphabetsObj.GetCharacter(alpha: letter);
            string res = alphabetsObj.CheckLUCase();
            MessageBox.Show("U have entered " + res + " letter",
                "Checking Alphabets Case...",MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}
