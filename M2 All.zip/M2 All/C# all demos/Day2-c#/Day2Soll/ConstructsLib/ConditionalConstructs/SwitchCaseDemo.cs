﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructsLib.Conditional_Constructs
{
  public  class Shapes
    {
        float area;//instance variable
        //Circle
        public float Circle(float radius)
        {
            area =(float) Math.PI * radius * radius;
            return area;
        }
        //Triangle

        public float Triangle(float b,float h)
        {
            area = (float)0.5 * b * h;
            return area;
        }
        //square
        public float Square(float s)
        {
            area = s * s;
            return area;
        }
        //rectangle
        public float Rectangle(float length,float breadth)
        {
            area = length * breadth;
            return area;
        }
    }
}
