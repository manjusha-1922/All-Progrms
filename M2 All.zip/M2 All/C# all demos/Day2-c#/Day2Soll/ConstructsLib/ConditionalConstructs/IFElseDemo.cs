﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructsLib
{
    public class Alphabets
    {
        char alpha;
        public void GetCharacter(char alpha)
        {
            this.alpha = alpha;
        }
        public string CheckLUCase()
        {
            string result;
            if (alpha >= 'A' && alpha <= 'Z')
                result = "Upper Case";

            else if (alpha >= 'a' && alpha <= 'z')
                result = "Lower Case";

            else if (alpha == ' ')
                result = "wrong key";

            else
                result = "Invalid";

            return result;
        }
    }
}
