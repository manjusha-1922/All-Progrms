﻿using System;
using System.Text;

namespace File_Io_Serialization_DeSerialization
{
    [Serializable]
   public class Customer
    {
        //private members
        public int cid;
        public string name;
      //  [NonSerialized] //omit persistancy
        public string address;
        //xml requires default constructor
        public Customer()
        {

        }

        //parametarised constructor
        public Customer(int cid,string name,string address)
        {
            this.cid = cid;
            this.name = name;
            this.address = address;
        }

        public string Display()
        {
            StringBuilder builderObj = new StringBuilder();
            builderObj.AppendLine("Customer details.....");
            builderObj.AppendLine("CId is " + cid);
            builderObj.AppendLine("Name is " + name);
            builderObj.AppendLine("Address is " + address);

            return builderObj.ToString();
        }
    }

    
}
