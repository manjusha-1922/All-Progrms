﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_Io_Serialization_DeSerialization
{
    class BinaryReaderWriter
    {
        static FileStream fsObj;
        #region write to binary file
        public static void WriteToFile()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(@"D:\FileIO\");;
            fsObj = new FileStream(directoryInfo.FullName + "binary.dat",
                FileMode.OpenOrCreate);

            BinaryWriter binaryWriterObj = new BinaryWriter(fsObj);

            //primitive data
            int i = 10;
            bool flag = true;
            double d = 10023.25;

            Console.WriteLine("Writing int i = 10 "+i);
            binaryWriterObj.Write(i);
            Console.WriteLine("Writing bool flag = true "+flag);
            binaryWriterObj.Write(flag);
            Console.WriteLine("Writing double d= 10023.25 "+d);
            binaryWriterObj.Write(d);
            Console.WriteLine("Writing 23.50 * 22.25 " +(23.50*22.25));
            binaryWriterObj.Write(23.50 * 22.25);

            binaryWriterObj.Flush();
            binaryWriterObj.Close();
            fsObj.Close();

            Console.WriteLine("\n\tBinary Writing is successfull...!");

        }
        #endregion

        
        #region read from binary file
        public static void ReadFromFile()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(@"D:\FileIO\"); ;
            fsObj = new FileStream(directoryInfo.FullName + "binary.dat",
                FileMode.Open);

            BinaryReader binaryReaderObj = new BinaryReader(fsObj);

            int j = binaryReaderObj.ReadInt32();
            Console.WriteLine("Reading from a file int i = 10.. "+j);

            bool status = binaryReaderObj.ReadBoolean();
            Console.WriteLine("reading from a file bool status = true.."+status);

            double res = binaryReaderObj.ReadDouble();
            Console.WriteLine("Reading from a file double res=10023.. " + res);

            Console.WriteLine("reading from file 23.50 * 22.25.."+
                binaryReaderObj.ReadDouble());

            binaryReaderObj.Close();
            fsObj.Close();
        }
        #endregion;
    }
}
