﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Soap;
using System.Text;
using System.Threading.Tasks;

namespace File_Io_Serialization_DeSerialization
{
    class SoapSerializationDeserialization
    {
        static FileStream fsObj = null;
        #region binary serialization

        public static void Soap_Serialize()
        {
            Directory.CreateDirectory(@"D:\FileIO\Soap");
            fsObj = new FileStream(@"D:\FileIO\Soap\customer.xml", FileMode.OpenOrCreate);
            SoapFormatter soapFormatterObj = new SoapFormatter();


            Console.WriteLine("\nFill customer Details ...");
            Console.WriteLine("Cid :-");
            int cid = int.Parse(Console.ReadLine());
            Console.WriteLine("Customer name :- ");
            string name = Console.ReadLine();
            Console.WriteLine("Customer address :- ");
            string address = Console.ReadLine();

            Customer customerObj = new Customer(cid, name, address);

            soapFormatterObj.Serialize(fsObj, customerObj);
            fsObj.Close();
            Console.WriteLine("Serialization successfull");
        }

        #endregion

        #region binary deserialization
        public static void Soap_DeSerialize()
        {
            fsObj = new FileStream(@"D:\FileIO\Soap\customer.xml", FileMode.Open);
            SoapFormatter soapFormatterObj = new SoapFormatter();

            Customer customer = (Customer)soapFormatterObj.Deserialize(fsObj);

            Console.WriteLine("Afer deserialization ");
            Console.WriteLine(customer.Display());
            fsObj.Close();
        }
        #endregion
    }
    class Serializable
    {
        static void Main(string[] args)
        {
            SoapSerializationDeserialization.Soap_Serialize();
            SoapSerializationDeserialization.Soap_DeSerialize();
        }
    }

}

