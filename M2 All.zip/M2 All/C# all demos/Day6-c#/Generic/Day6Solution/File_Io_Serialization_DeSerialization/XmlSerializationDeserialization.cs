﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace File_Io_Serialization_DeSerialization
{
    class XmlSerializationDeserialization
    {
        
            static FileStream fsObj = null;
            #region binary serialization

            public static void Xml_Serialize()
            {
                Directory.CreateDirectory(@"D:\FileIO\Xml");
                fsObj = new FileStream(@"D:\FileIO\Xml\customer.xml", FileMode.OpenOrCreate);
                XmlSerializer xmlSerializerObj = new XmlSerializer(typeof(Customer));


                Console.WriteLine("\nFill customer Details ...");
                Console.WriteLine("Cid :-");
                int cid = int.Parse(Console.ReadLine());
                Console.WriteLine("Customer name :- ");
                string name = Console.ReadLine();
                Console.WriteLine("Customer address :- ");
                string address = Console.ReadLine();

                Customer customerObj = new Customer(cid, name, address);

               xmlSerializerObj.Serialize(fsObj, customerObj);
                fsObj.Close();
                Console.WriteLine("Serialization successfull");
            }

            #endregion

            #region binary deserialization
            public static void Xml_DeSerialize()
            {
                fsObj = new FileStream(@"D:\FileIO\Xml\customer.xml", FileMode.Open);
                XmlSerializer xmlSerializerObj = new XmlSerializer(typeof(Customer));

                Customer customer = (Customer)xmlSerializerObj.Deserialize(fsObj);

                Console.WriteLine("Afer deserialization ");
                Console.WriteLine(customer.Display());
                fsObj.Close();
            }
            #endregion
        }
        class XmlSerialize
        {
            static void Main(string[] args)
            {
                XmlSerializationDeserialization.Xml_Serialize();
                XmlSerializationDeserialization.Xml_DeSerialize();
            }
        }
    }

