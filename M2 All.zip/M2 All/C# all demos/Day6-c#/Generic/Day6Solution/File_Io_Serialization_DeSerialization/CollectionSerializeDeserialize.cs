﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace File_Io_Serialization_DeSerialization
{
    class CollectionSerializeDeserialize
    {
        static FileStream fsObj = null;
        #region binary serialization

        public static void Binary_Serialize()
        {
            fsObj = new FileStream(@"D:\FileIO\Binary\customerlist.bin", FileMode.OpenOrCreate);
            BinaryFormatter binaryFormatterObj = new BinaryFormatter();
            List<Customer> custList = new List<Customer>();
            char choice = 'y';

            do
            {
                Console.WriteLine("\nFill customer Details ...");
                Console.WriteLine("Cid :-");
                int cid = int.Parse(Console.ReadLine());
                Console.WriteLine("Customer name :- ");
                string name = Console.ReadLine();
                Console.WriteLine("Customer address :- ");
                string address = Console.ReadLine();

                Customer customerObj = new Customer(cid, name, address);
                custList.Add(customerObj);
                Console.WriteLine("Do u want to continue ? " + "Press y for yes & n for no");
                choice = char.Parse(Console.ReadLine());

            } while (char.ToUpper(choice) == 'Y');

            binaryFormatterObj.Serialize(fsObj, custList);
            fsObj.Close();
            Console.WriteLine("Serialization successfull");
        }

        #endregion

        #region binary deserialization
        public static void Binary_DeSerialize()
        {
            fsObj = new FileStream(@"D:\FileIO\Binary\customerlist.bin", FileMode.Open);
            BinaryFormatter binaryFormatterObj = new BinaryFormatter();

           List< Customer> custList = (List<Customer>)binaryFormatterObj.Deserialize(fsObj);

            Console.WriteLine("Afer deserialization ");
            foreach(Customer customerObj in custList)
            Console.WriteLine(customerObj.Display());

            Console.WriteLine();

            Console.WriteLine("Search By Id : ");
            int cid = int.Parse(Console.ReadLine());
            foreach(Customer customerObj in custList)
            {
                if(customerObj.cid==cid)
                    Console.WriteLine(customerObj.Display());
            }
            fsObj.Close();
        }
        #endregion
    }
        class CollectionSerialize
        {
            static void Main(string[] args)
            {
                CollectionSerializeDeserialize.Binary_Serialize();
                CollectionSerializeDeserialize.Binary_DeSerialize();
        }
        }
    }