﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_Io_Serialization_DeSerialization
{
    class program
    {
        static void Main(string[] args)
        {
            //stream reader and writer
            /*StreamReaderWriter.WriteToFile();
             StreamReaderWriter.ReadFromFile();*/

            //binary file reader and writer
            /*  BinaryReaderWriter.WriteToFile();
              BinaryReaderWriter.ReadFromFile();*/

            DirectoryAndFile.Example1();
            DirectoryAndFile.Example2();
        }

    }
}
