﻿using System;
using System.IO;


namespace File_Io_Serialization_DeSerialization
{
    class StreamReaderWriter
    {
       static FileStream fsObj;

        #region writing stream of characters to file

        public static void WriteToFile()
        {
            DirectoryInfo diObj = Directory.CreateDirectory(@"D:\FileIO");

            Console.WriteLine("Full Path of the directory " + diObj.FullName);

            fsObj = new FileStream(diObj.FullName + @"\emp.txt", FileMode.OpenOrCreate);
            /*,FileAccess.Write,
              FileShare.Read*/

            StreamWriter streamWriterObj = new StreamWriter(fsObj);
            Employee empObj = new Employee();
            Console.WriteLine("Fill Employee Details....");

            Console.WriteLine("EId :");
            empObj.EId = int.Parse(Console.ReadLine());

            Console.WriteLine("Name :");
            empObj.Name = Console.ReadLine();

            Console.WriteLine("Salary :");
            empObj.Salary = float.Parse(Console.ReadLine());

            Console.WriteLine("Designation :");
            empObj.Design = Console.ReadLine();

            Console.WriteLine("Writing employee details to file..");

            streamWriterObj.WriteLine(empObj.Name + "\tdetails are as follows");
            streamWriterObj.WriteLine("EId is " + empObj.EId);
            streamWriterObj.WriteLine("Name is " + empObj.Name);
            streamWriterObj.WriteLine("Designation is " + empObj.Design);
            streamWriterObj.WriteLine("Salary is " + empObj.Salary);
            streamWriterObj.WriteLine();
            //when even u write stream of characters to file 
            //always close stream
            streamWriterObj.Flush();
               
            streamWriterObj.Close();
        }
        #endregion

        public static void ReadFromFile()
        {
            fsObj = new FileStream(@"D:\FileIO\emp.txt", FileMode.Open);
            StreamReader streamReaderObj = new StreamReader(fsObj);

            //c# reading complete line in one go
            Console.WriteLine(streamReaderObj.ReadToEnd());

            //move ur cursor explicitly to the begning of the file
            streamReaderObj.BaseStream.Seek(0, SeekOrigin.Begin);

            Console.WriteLine("\n\nAgain reading from the begning");
            
            //Java Style - Reading line by line
            string readLinebyLine = streamReaderObj.ReadLine();
            while(readLinebyLine != null)
            {
                Console.WriteLine(readLinebyLine);
                readLinebyLine = streamReaderObj.ReadLine();
            }
           
            streamReaderObj.Close();
            fsObj.Close();
            
        }
    }
}
