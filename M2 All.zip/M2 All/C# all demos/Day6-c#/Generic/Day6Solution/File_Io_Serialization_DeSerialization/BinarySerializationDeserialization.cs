﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace File_Io_Serialization_DeSerialization
{
    class BinarySerializationDeserialization
    {
       static FileStream fsObj = null;
        #region binary serialization
        
        public static void Binary_Serialize()
        {
            fsObj = new FileStream(@"D:\FileIO\Binary\customer.bin", FileMode.OpenOrCreate);
            BinaryFormatter binaryFormatterObj = new BinaryFormatter();


            Console.WriteLine("\nFill customer Details ...");
            Console.WriteLine("Cid :-");
            int cid = int.Parse(Console.ReadLine());
            Console.WriteLine("Customer name :- ");
            string name = Console.ReadLine();
            Console.WriteLine("Customer address :- ");
            string address = Console.ReadLine();

            Customer customerObj = new Customer(cid,name,address);

            binaryFormatterObj.Serialize(fsObj, customerObj);
            fsObj.Close();
            Console.WriteLine("Serialization successfull");
        }

        #endregion

        #region binary deserialization
        public static void Binary_DeSerialize()
        {
            fsObj = new FileStream(@"D:\FileIO\Binary\customer.bin", FileMode.Open);
            BinaryFormatter binaryFormatterObj = new BinaryFormatter();

          Customer customer=(Customer)binaryFormatterObj.Deserialize(fsObj);

            Console.WriteLine("Afer deserialization ");
            Console.WriteLine(customer.Display());
        }
        #endregion
    }

    class Serializatoin
    {
        static void Main(string[] args)
        {
            BinarySerializationDeserialization.Binary_Serialize();
            BinarySerializationDeserialization.Binary_DeSerialize();
        }
    }
}
