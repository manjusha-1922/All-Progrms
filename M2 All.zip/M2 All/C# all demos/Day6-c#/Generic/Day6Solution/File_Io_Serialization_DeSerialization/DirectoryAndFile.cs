﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_Io_Serialization_DeSerialization
{
    class DirectoryAndFile
    {
        //
        public static void Example1()
        {
            string path = @"D:\FileIO\Binary";

            try
            {
                //if (Directory.Exists(path))
                //{
                //    Directory.Delete(path);
                //    return;
                //}
                DirectoryInfo diInfo = Directory.CreateDirectory(path + @"\Demo");

                Console.WriteLine("Folder Name " + diInfo.Name);
                Console.WriteLine("Full path " + diInfo.FullName);
                Console.WriteLine("Creation Time " + diInfo.CreationTime);
                Console.WriteLine("Last accessed time " + diInfo.LastAccessTime);

                File.Create(diInfo.FullName + @"\sample.txt");

                FileInfo fileInfo = new FileInfo(diInfo.FullName + @"\sample.txt");

                Console.WriteLine("Folder Name " + fileInfo.Name);
                Console.WriteLine("Full path " + fileInfo.FullName);
                Console.WriteLine("Creation Time " + fileInfo.CreationTime);
                Console.WriteLine("Last accessed time " + fileInfo.LastAccessTime);

                Console.WriteLine("File Exists " + fileInfo.Exists);
                Console.WriteLine("Folder Exists " + diInfo.Exists);

                if (fileInfo.Exists)
                {
                    //File.Delete(diInfo.FullName + @"\sample.txt");
                    fileInfo.Delete();
                    diInfo.Delete();
                } 

                Console.WriteLine("File Exists " + fileInfo.Exists);
                Console.WriteLine("Folder Exists " + diInfo.Exists);
            }
            catch (Exception) { }
        }

      //scanning folders and files

      public static void Example2()
        {
            DirectoryInfo diInfo = new DirectoryInfo(@"D:\FileIO");
            FileInfo[] fileInfo = diInfo.GetFiles();
            DirectoryInfo[] directoryInfo = diInfo.GetDirectories();

            foreach (var file in fileInfo)
            {
                // Console.WriteLine("File Name : {0}",file.Name);
                Console.WriteLine($"File Name : {file.Name}\nFile path "+
                    $"{file.FullName}\n File size {file.Length} in bytes");
            }

            

            foreach (var directory in directoryInfo)
            {
                // Console.WriteLine("File Name : {0}",file.Name);
                Console.WriteLine($"Directory Name : {directory.Name}\nDirectory path " +
                    $"{directory.FullName}");
            }
        }

        public static void Example3()
        {

        }
    }
}
