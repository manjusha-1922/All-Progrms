﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_Io_Serialization_DeSerialization
{
    class Employee
    {
        public int EId { get; set; }

        public string Name { get; set; }

        public string Design { get; set; }

        public float Salary { get; set; }
    }
}
