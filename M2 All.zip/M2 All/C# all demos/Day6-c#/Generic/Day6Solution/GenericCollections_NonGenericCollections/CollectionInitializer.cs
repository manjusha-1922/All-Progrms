﻿using System;
using System.Collections.Generic;


namespace GenericCollections_NonGenericCollections
{
    class Employee
    {
        public int EId { get; set; }

        public string Name { get; set; }

        public string Design { get; set; }

        public float Salary { get; set; }
    }
    class CollectionInitializer
    {
        static void Main(string[] args)
        {
            List<Employee> employeeList = new List<Employee>
            {
                new Employee {EId=101,Name="Abc",Design="Developer",Salary=25000 },

                new Employee {EId=102,Name="Def",Design="Developer",Salary=26000 },

                new Employee {EId=103,Name="Hij",Design="Analyst",Salary=29000 },

                new Employee {EId=104,Name="Nmb",Design="Tester",Salary=30000 },

                new Employee {EId=105,Name="Fgh",Design="Developer",Salary=25000 },
            };

            foreach(var employee in employeeList)
            {
                Console.WriteLine(employee.Name+"\t"+employee.Salary);
            }
        }
    }
}
