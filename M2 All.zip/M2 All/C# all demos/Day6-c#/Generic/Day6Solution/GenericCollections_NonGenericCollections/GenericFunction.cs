﻿using System;


namespace GenericCollections_NonGenericCollections
{
    class Shape
    {
        public static T Operation<T>(T x)
        {
            dynamic result = 0;
            if(x is int)
            {
                dynamic s = x;
              result = s * s;
            }
           

            else if(x is float)
            {
                dynamic r = x;
                result = 2 * 3.14f * r;
            }
            

            else if (x is double)
                {
                dynamic r = x;
                result = 3.14 * r * r;
            }
            return result;
        }
    }
    class GenericFunction
    {
        static void Main(string[] args)
        {



            Console.WriteLine("Area of square " + Shape.Operation<int>(2));
            Console.WriteLine("Circumference of Circle " + Shape.Operation<float>(2));
            Console.WriteLine("Area of Circle " + Shape.Operation<double>(2));

        }
    }
}
