﻿using System;
using System.Collections;

namespace GenericCollections_NonGenericCollections
{
    class NonGenericCollectionClass

    {
        #region Array List Function
        public static void ArrayListFunc()
        {
            ArrayList namesList = new ArrayList();
            namesList.Add("sai");
            namesList.Add("krishna");
            namesList.Add("ram");
            namesList.Add("charan");

            Console.WriteLine("Print List...");
            foreach (var name in namesList)
            {
                Console.WriteLine("\t" + name);
            }

            //it gives error during sorting
            //namesList.Add(5);

            Console.WriteLine("\nAfter adding Arjun..");
            namesList.Add("Arjun");
            foreach (var name in namesList)
            {
                Console.WriteLine("\t" + name);
            }

            namesList.Sort();
            Console.WriteLine("\nAfter sort.. in ascending order");
            foreach (var name in namesList)
            {
                Console.WriteLine("\t" + name);
            }

            namesList.Reverse();
            Console.WriteLine("\nAfter sort.. in descending order");
            foreach (var name in namesList)
            {
                Console.WriteLine("\t" + name);
            }

            Console.WriteLine("Add nani afer charan");
            namesList.Insert(4, "Nani");

            foreach (var name in namesList)
            {
                Console.WriteLine("\t" + name);
            }

            Console.WriteLine("Remove Ram");
            namesList.Remove("Ram");
            foreach (var name in namesList)
            {
                Console.WriteLine("\t" + name);
            }

            Console.WriteLine("Total Elements : " + namesList.Count);
            Console.WriteLine("Total Elements : " + namesList.Capacity);
        }

        #endregion

        #region Stack Function

        public static void stackFunc()
        {
            Stack seqObj = new Stack();
            seqObj.Push(1);
            seqObj.Push(2);
            seqObj.Push(3);
            seqObj.Push(4);

            Console.WriteLine("Print Sequence ");
            foreach (var seq in seqObj)
            {
                Console.WriteLine("\t" + seq);
            }
            //both peek and pop returns object the difference is pop returns and removes from list
            //where as peek just returns
            Console.WriteLine("The top most element from the stack is" + seqObj.Peek());

            Console.WriteLine("Removing top most element " + seqObj.Pop());

            Console.WriteLine("\n Print using for loop");
            int[] p = new int[seqObj.Count];
            //copy stack list to user created array
            seqObj.CopyTo(p, 0);
            for (int i = 0; i < seqObj.Count; i++)
            {
                Console.WriteLine("\t" + p[i]);
            }

            Console.WriteLine("\n print using forEach");
            foreach (var seq in seqObj)
            {
                Console.WriteLine("\t" + seq);
            }
        }


        #endregion

        #region Queue Function

        public static void QueueFunc()
        {
            Queue msgs = new Queue();
            msgs.Enqueue("Hi");
            msgs.Enqueue("Hello");
            msgs.Enqueue("Welcome");

            Console.WriteLine("\nMy Messages");
            foreach (var msg in msgs)
            {
                Console.WriteLine("\t" + msg);
            }

            msgs.Dequeue();
            Console.WriteLine("\nFirst msg is delivered..");
            Console.WriteLine("Remaining msgs from queue..");
            foreach (var msg in msgs)
            {
                Console.WriteLine("\t" + msg);
            }
        }

        #endregion

        #region Hashtable Function
        public static void HashtableFunc()
        {
            Hashtable empList = new Hashtable();
            empList.Add("A", "Arjun");
            empList.Add('A', "Amith");
            empList.Add('a', "Ashi");
            empList.Add("C", "Charan");

            foreach (var k in empList.Keys)
            {
                Console.WriteLine(k + "\t" + empList[k]);
            }

            if (empList.ContainsKey("S"))
                Console.WriteLine(empList["S"]);

            if (empList.ContainsValue("Charan"))
                Console.WriteLine("true");
        }
    }
        #endregion

        class CallingNonGenericFunction
    {
        static void Main(string[] args)
        {
            NonGenericCollectionClass.ArrayListFunc();
            NonGenericCollectionClass.stackFunc();
            NonGenericCollectionClass.QueueFunc();
            NonGenericCollectionClass.HashtableFunc();
        }
    }
}
