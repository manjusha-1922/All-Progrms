﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Attributes_Reflection
{
    class Circle
    {
        float r;
        public float Radius { get; set; }

        public Circle(float radius)
        {
            this.Radius = radius;
        }

        [Obsolete("This function is outdated")]

        public void CalculateArea()
        {

        }
    }
    class ReflectionOnAssemply
    {
        static void Main(string[] args)
        {
            new Circle(20).CalculateArea();

            Type type = typeof(Circle);
            Console.WriteLine("Name :" + type.Name);
            Console.WriteLine("Full Name :" + type.FullName);
            Console.WriteLine("Name Space" + type.Namespace);
            Console.WriteLine("Is It a class :" + type.IsClass);

            foreach (var method in type.GetMethods())
            {
                // Console.WriteLine(method);
                Console.WriteLine(method.IsPublic + " " + method.Name);
            }

            Console.WriteLine("\nList of constructors");
            foreach (var constructor in type.GetConstructors())
            {
                // Console.WriteLine(method);
                Console.WriteLine(constructor.IsPublic + " " + constructor.Name);
            }

            Console.WriteLine("\nList of properties");
            foreach (var property in type.GetProperties())
            {
                // Console.WriteLine(method);
                Console.WriteLine(property);
            }

            Console.WriteLine("\nList of fields ");
            foreach (var field in type.GetFields())
            {
                // Console.WriteLine(method);
                Console.WriteLine(field);
            }
            Console.WriteLine("\nTypes");
            var types = Assembly.GetExecutingAssembly().GetTypes();
            foreach (var t in types)
            {
                Console.WriteLine(t);
            }
        }
     }

        struct MyStruct
        {

        }

        enum MyEnum
        {

        }
    
}
