﻿using System;
using System.Reflection;

namespace Attributes_Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 100;
            Type tObj = i.GetType();

            Console.WriteLine("i type : "+tObj);

            Assembly existingAssembly = typeof(System.Int32).Assembly;
            Console.WriteLine(existingAssembly);
            Console.WriteLine();

            existingAssembly = Assembly.GetExecutingAssembly();
            Console.WriteLine(existingAssembly);

            Console.WriteLine("Full Name : "+existingAssembly.FullName);

            AssemblyName assemblyNameObj = existingAssembly.GetName();

            Console.WriteLine("\n Full Name : "+assemblyNameObj.FullName);

            Console.WriteLine("\n Name :"+assemblyNameObj.Name);

            Console.WriteLine("\nVersion "+assemblyNameObj.Version.Major+"."+assemblyNameObj.Version.Minor);
           
        }
    }
}
