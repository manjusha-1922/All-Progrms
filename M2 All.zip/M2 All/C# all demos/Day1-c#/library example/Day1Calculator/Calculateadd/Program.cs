﻿using System;
using CalculatorLibrary;
namespace CalculatorLibrary_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator addObj = new Calculator();
            addObj.Initialize(40, 20);
            float result = addObj.CalculateAdd();
            Console.WriteLine("addition of two numbers is " + result);

            
        }
    }
}
