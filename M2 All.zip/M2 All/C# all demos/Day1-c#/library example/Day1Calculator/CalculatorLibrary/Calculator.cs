﻿using System;


namespace CalculatorLibrary
{
    public class Calculator
    {
        float num1, num2; //instance variables
        float result;

        public void Initialize(float num1, float num2) /*local variables*/
        {
            /*this key word is avoiding ambiguty betwem instance and local variable.
                     this points to current class*/
            this.num1 = num1;
            this.num2 = num2;
        }
       
            

        public float CalculateAdd()
        {
            result = num1 + num2;
            return result;
        }
        public float Calculatesub()
        {
            result = num1 - num2;
            return result;
        }
        public float Calculatemul()
        {
            result = num1 * num2;
            return result;
        }
        public float Calculatediv()
        {
            result = num1 / num2;
            return result;
        }
    }
}
