﻿using System;


namespace ShapeLibrary
{
   public class Triangle
    {
        //data members / attributes
        float b, h; //instance variables
        float area;
        public void Initialize(int b,int h) /*local variables*/
        {
            /*this key word is avoiding ambiguty betwem instance and local variable.
                     this points to current class*/
            this.b = b;
            this.h = h;
        }
        public float CalculateArea()
        {
            area = 0.5f * b * h;
            return area;
        }
    }
}
