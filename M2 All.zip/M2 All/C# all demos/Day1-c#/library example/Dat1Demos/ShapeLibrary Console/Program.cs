﻿using System;
using ShapeLibrary;
namespace ShapeLibrary_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Triangle triangleObj = new Triangle();
            triangleObj.Initialize(10, 20);
            float area = triangleObj.CalculateArea();
            Console.WriteLine("area of triangle is "+area);

            triangleObj.Initialize(h:2, b:20);
            area = triangleObj.CalculateArea();
            Console.WriteLine("area of triangle is " + area);

        }
    }
}
