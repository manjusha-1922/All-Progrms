
using System; //using name space
class HelloWorld
{

   public static void Main(string []args)
    {
      System.Console.WriteLine("Welcome to c#");
	  System.Console.ReadKey();
	  //System.Console.ReadLine();//this will press enter key to be pressed
    }


}