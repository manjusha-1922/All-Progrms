
/*Calculate area of rectangle*/
using System;
class Rectangle
{
   public static void Main()
    {
          //declare variables
         float length,breadth,area;
         //prompt user to accept length and breadth
         Console.Write("Length:");
         length=float.Parse(Console.ReadLine());	
		 
		 Console.Write("Breadth:");
         breadth=float.Parse(Console.ReadLine());
		 
		 //calculate area
		 area=length*breadth;
		 
		 Console.WriteLine("Area of Rectangle"+area);
		 //Console.WriteLine("Area of Rectangle {0}",area);
	}


}