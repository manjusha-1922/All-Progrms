/*calculate area of circle*/
using System;

  class Circle
   {
     public static void Main()
	   {
	      float area,radius;
		  const float pi =3.14f;
		  
		  Console.Write("enter radius of circle");
		  radius=float.Parse(Console.ReadLine());
		  
		  //calculate area
		  
		  area=pi*radius*radius;
		  
		  Console.Write("area of circle is :"+area);
		 }
	}	 
		  