﻿using System;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            num3 = 0;

            try
            {
                Console.WriteLine("Num1 :- ");
                num1 = int.Parse(Console.ReadLine());

                Console.WriteLine("Num2 :- ");
                num2 = int.Parse(Console.ReadLine());

                num3 = num1 / num2;

            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Exception Caught:- " + ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Exception Caught:- "+ ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Caught:- "+ ex.Message);
            }

            finally
            {
                Console.WriteLine("Num3 :- " + num3);
            }
        }

    }
}
