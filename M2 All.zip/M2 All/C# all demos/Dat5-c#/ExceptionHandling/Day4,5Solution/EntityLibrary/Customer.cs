﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLibrary
{
    public class Customer
    {
        public int Cid { get; set; }

        public string Name { get; set; }

        public string Mobilenumber { get; set; }
    }
}
