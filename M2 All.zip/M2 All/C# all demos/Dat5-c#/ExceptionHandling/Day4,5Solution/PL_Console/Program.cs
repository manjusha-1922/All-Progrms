﻿using BusinessLogicLayer;
using EntityLibrary;
using ExceptionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PL_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer cObj = new Customer();
            Console.WriteLine("CId :- ");
            cObj.Cid = int.Parse(Console.ReadLine());
            Console.WriteLine("Name :- ");
            cObj.Name = Console.ReadLine();
            Console.WriteLine("Mobile Number :- ");
            cObj.Mobilenumber = Console.ReadLine();

            Customer_BL customerBLObj = new Customer_BL();
            string details = null;
            try
            {
                details = customerBLObj.Display(cObj);
            }
            catch(InvalidMobileNumberException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(InvalidCidException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine(details);
                Console.ReadKey();
            }
        }
    }
}
