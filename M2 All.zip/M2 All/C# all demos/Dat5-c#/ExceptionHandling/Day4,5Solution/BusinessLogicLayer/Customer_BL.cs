﻿using EntityLibrary;
using ExceptionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class Customer_BL
    {
       private bool ValidateMobileNumber(Customer customerObj)

        {
            if(customerObj.Mobilenumber.Length!=10)
            {
                throw new InvalidMobileNumberException
                    ("Error : Mobile number must be of 10 digits..!");
            }

            else if (!Regex.IsMatch(customerObj.Mobilenumber,"[6-9][0-9]{9}"))
            {
                throw new InvalidMobileNumberException
                     ("Error : Mobile number must begin between 6 to 9..!");
            }
            else
            {
                return true;
            }
        }

        private bool validateCid(Customer customerObj)
        {
            if (customerObj.Cid < 0)
            {
                throw new InvalidCidException
                    ("Error : Mobile number must be of greater than 0..!");
            }
            else
            {
                if ((customerObj.Cid > 100 && customerObj.Cid < 200))
                {
                    throw new InvalidCidException
                         ("Error :customer id must be between with 100 to 200..!");
                }
                else
                {
                    return true;
                }
            }
        }

        public string Display(Customer customerObj)
        {
            StringBuilder builderObj = new StringBuilder();
            if (ValidateMobileNumber(customerObj) && validateCid(customerObj))
            {
                
                builderObj.AppendLine("customer Details are....");
                builderObj.AppendLine("customer id is " + customerObj.Cid);
                builderObj.AppendLine("customer Name is " + customerObj.Name);
                builderObj.AppendLine("customer mobile number is " + customerObj.Mobilenumber);
            }

            else
            {
                builderObj.Append("Error: Validation Failed");
            }
            return builderObj.ToString();
        }
    }

}
