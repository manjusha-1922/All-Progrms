﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLibrary
{
    public class InvalidCidException : ApplicationException
    {
        public InvalidCidException()
        {

        }


        public InvalidCidException(string message) : base(message)
        {

        }
    }
    
}
