﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLibrary
{
    public class InvalidMobileNumberException : ApplicationException
    {
        public InvalidMobileNumberException()
        {

        }


        public InvalidMobileNumberException(string message) : base(message)
        {

        }
    }
}
