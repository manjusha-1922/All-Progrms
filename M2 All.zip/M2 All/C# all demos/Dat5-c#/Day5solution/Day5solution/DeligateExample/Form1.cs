﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeligateExample
{
    public partial class Form1 : Form
    {

        // 1.Define deligate 
        delegate string MyDelegate(string message);
        // 2. Create event on deligate
        event MyDelegate LowerEvent;
        event MyDelegate UpperEvent;
        // 3.Event Handlers
        public string ConvertToLower(string message)//subscribers
        {
            return message.ToLower();
        }
        public string ConvertToUpper(string message)//subricers
        {
            return message.ToUpper();
        }
        public Form1()
        {
            InitializeComponent();
        }

        //Upper Case
        private void button1_Click(object sender, EventArgs e)
        {
            this.UpperEvent = new MyDelegate(ConvertToUpper);
            MessageBox.Show(UpperEvent(textBox1.Text));
        }

        //Lower Case
        private void button2_Click(object sender, EventArgs e)
        {
            this.LowerEvent = new MyDelegate(ConvertToLower);
            MessageBox.Show(LowerEvent(textBox1.Text));
        }
    }
}
