﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesExample
{
    class Lambda_AnonymousFunctions
    {
        static void Main(string[] args)
        {
            Action<float, float> multiply = Calculator.Multiplication;
            multiply(10, 20);

            //Anonymous functions

            Action<float, float> substraction = delegate (float a, float b)
               {
                   Console.WriteLine("substraction is : " + (a - b));
               };

            substraction(20, 10);

            //Anonymous Function - with function deligate
            //in func deligate last parameter will be return value
            Func<float, float, float> rectangle = delegate (float l, float b)
                {
                    return l * b;
                };

            Console.WriteLine("area of rectangle is "  +rectangle(10,20));

            //Lambda Expression [=> operatot]

            Func<float,float,float> triangle = (b,h) => { return 0.5f * b * h; };
            Console.WriteLine("Area of triangle is "+triangle(10,20));

            Func<int, int> square = (side) => { return side * side; };
            Console.WriteLine("Area of square is "+square(10));

            Action<float> circle = (radius) => 
            Console.WriteLine("Area of circle is "+3.14*radius*radius);
            circle(2);
                
        }
    }
}
