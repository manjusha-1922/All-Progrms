﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesExample
{
    
    
    // 1.defining deligate
    delegate void Operation(float a, float b);


    class Calculator
    {
        //handlers
       public static void Addition(float n1,float n2)
        {
            Console.WriteLine("Addition is "+ (n1+n2));
        }
        public static void Multiplication(float n1, float n2)
        {
            Console.WriteLine("Multiplication  is " + (n1 * n2));
        }
    }
}
