﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesExample
{
    delegate void Calculate(int a, int b);

    class Math
    {
        public void MultiplyNumbers(int firstNumber,int secondNumber)
        {
            Console.WriteLine("Multiplication of two numbers is :"+
                firstNumber*secondNumber);
        }
    }
        
        

    class Deligate_Lambda_Anynomous
    {

        static void Main(string[] args)
        {
            Math mObj = new Math();
            
            Calculate cObj ;

            cObj = mObj.MultiplyNumbers;

            cObj.Invoke(10, 20);

            //using anynomous method

            cObj = delegate (int num1, int num2)
            {
                int num3 = num1 * num2;
                Console.WriteLine("Multiplication is " + num3);
            };
            cObj(20, 30);

            //using lambda expression
            cObj = (num1, num2) =>
              {
                  int num3 = num1 * num2;
                  Console.WriteLine("Using Lambda expression" + num3);
              };
            cObj(20, 30);
        }
    }
}
