﻿using System;

namespace DeligatesExample
{
    //Generic Deligate
    delegate T OperationDeligate<T>(T a, T b);
    class Maths
     {
            public static float product(float a,float b)
        {
            return a * b;
        }
           public static int modulo(int a, int b)
        {
            return a % b;
        }
        public static double minus(double a, double b)
        {
            return a - b;
        }
    }
    class GenericDeligate
    {
        static void Main(string[] args)
        {
            //create deligate object,assocating function
            OperationDeligate<int> modulo = Maths.modulo;

            //invoke function
            Console.WriteLine("Modulo is :" + modulo(11,2));
            Console.WriteLine("Modulo is :" + modulo.Invoke(11, 2));

            OperationDeligate<float> product = Maths.product;
            Console.WriteLine("Product is :" + product(11, 2));


            OperationDeligate<double> minus = Maths.minus;
            Console.WriteLine("Product is :" + minus(11, 2));


        }
    }
}
