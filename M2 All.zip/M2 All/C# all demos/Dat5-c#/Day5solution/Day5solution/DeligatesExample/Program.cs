﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 2. create deligate object
            Operation operationObj;

            // 3.point or load function inside deligate object
            //single cast deligate
            operationObj = Calculator.Addition;

            // 4. invoke deligate
            operationObj.Invoke(10, 30);
            
            //we can add multiple references to deligate object using [+=] 
            operationObj += Calculator.Multiplication;
            operationObj(50, 30);
            
            //to remove addition reference we use [-=]
            operationObj -= Calculator.Addition;
            operationObj(10, 20);


        }
    }
}
