﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeLibrary
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]

    public class CustomerCategoryAttribute : Attribute
    {
        private string categoryType;

        public string CategoryType
        {
            get
            {
              return  categoryType;
            }

            set
            {
                if (value.ToLower() == "previlaged " || value.ToLower() == "non previlaged")
                    categoryType = value;
                else
                    categoryType = string.Empty;

            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryType"></param>

        public CustomerCategoryAttribute(string categoryType)
        {
            this.categoryType = categoryType;
        }
    }
}
