﻿using AttributeLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttribute
{
    [Serializable]
    [CustomerCategory(categoryType:"previlaged")]

    class Customer
    {

    }
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            CustomerCategoryAttribute myAttribute
                =(CustomerCategoryAttribute)

            Attribute.GetCustomAttribute(typeof(Customer), typeof(CustomerCategoryAttribute));

            if (myAttribute == null)
            {
                Console.WriteLine("Attribute is not applied on customer");
            }
            else
            {
                Console.WriteLine("Attribute is applied on customer class");
                Console.WriteLine("Customer is "+myAttribute.CategoryType);
            }
            DateTime dateTime = new DateTime();
            Console.WriteLine(dateTime);
            Console.WriteLine(DateTime.Now);
            Console.WriteLine(DateTime.Now.ToShortDateString());
            //or
            Console.WriteLine(DateTime.Now.ToString("dd-MM-yyyy"));

            Console.WriteLine(DateTime.Now.ToShortTimeString());
            //or
            Console.WriteLine(DateTime.Now.ToString("hh-mm-ss"));
        }
    }
}
