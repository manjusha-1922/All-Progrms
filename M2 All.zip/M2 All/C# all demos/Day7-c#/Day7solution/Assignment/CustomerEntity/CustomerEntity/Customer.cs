﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerEntity
{
    public class Customer
    {
        public int CId { get; set; }

        public string Cname { get; set; }

        public string City { get; set; }
    }
}
