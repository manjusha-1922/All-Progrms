﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_Exception
{
    public class CustomerException: ApplicationException
    {
        public CustomerException()
            : base()
        {
        }

        public CustomerException(string message)
            : base(message)
        {
        }
        public CustomerException(string message, System.Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
