﻿using Customer_Exception;
using CustomerEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Customer_DAL;

namespace Customer_BLL
{
    public class CustomerValidation
    {
        private static bool ValidateCustomer(Customer custObj)
        {
            StringBuilder sb = new StringBuilder();
            bool validCustomer = true;

            try {
                if (custObj.Cname==string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer Name Required");
                }

                if(custObj.CId.ToString() ==string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Invalid Customer ID");
                }

                if(custObj.City==string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "City name should be provided");
                }
                else if(custObj.City!="Mumbai" && custObj.City!="Delhi" && custObj.City!="Bangalore" && 
                    custObj.City!="Puna")
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "City name should either Mumbai or Delhi or Pune or Banglore");
                }
                if (validCustomer == false)
                    throw new CustomerException(sb.ToString());
                return validCustomer;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validCustomer;

        }

        public static void InsertCustomer(Customer custObj)
        {
            try
            {
                if(ValidateCustomer(custObj))
                {
                    Customer_DataAccessLayer.InsertCustomer(custObj);
                }
                else
                    throw 
            }
        }
    }
}
