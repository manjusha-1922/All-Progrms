﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentEntity
{
    /// <summary>
    /// Grade Enumeration, Values can be A,B,C,D,E
    /// </summary>
    public enum Grade
    {
        A =1 ,B,C,D,E
    }
    /// <summary>
    /// Author:CG
    /// DOC:23rd Jan 2017
    /// Purpose: To create an Entity Class for SMS
    /// </summary>
   [Serializable]
    public class Student
    {
        public int StudentId { get; set; }
        public string StudentName {get; set; }

        public long StudentPhoneNo { get; set; }

        public string StudentEmail { get; set; }

        public string StudentDept { get; set; }

        public Grade StudentGrade { get; set; }
    }
}
