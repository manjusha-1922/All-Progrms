﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Exception;
using Project.BusinessLogicLyer;
using Project.entity;

namespace Project.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Menu();

                Console.Write("Choice :- ");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        {
                            Accept();
                        }

                        break;

                    case 2:
                        {
                            Display();
                        }

                        break;

                    case 0:

                        Environment.Exit(0);
                        break;
                }

            }
        }

        static void Menu()
        {
            Console.WriteLine("\n\t\tMenu:-");
            Console.WriteLine("\t\t1 - Add Project");
            Console.WriteLine("\t\t2 - Display Project");
            Console.WriteLine("\t\t0 - Exit");
        }

        static void Accept()
        {
            Project.entity.Project newProject
              = new Project.entity.Project();

            try
            {
                Console.Write("Projectid :- ");

                newProject.ProjectId = int.Parse(Console.ReadLine());

                Console.Write("ProjectName :- ");

                newProject.ProjectName = Console.ReadLine();

                Console.Write("ClientName :- ");

                newProject.ClientName = Console.ReadLine();

                Console.Write("StartDate :- ");

                newProject.StartDate =DateTime.Parse(Console.ReadLine());

                Console.Write("EndDate :- ");
                newProject.StartDate = DateTime.Parse(Console.ReadLine());

              //  newProject.EndDate = DateTime.Today.AddMonths(6);

                Console.Write("Status :- ");
                newProject.Status = Console.ReadLine();
                

            //    Console.WriteLine("OnGoing");

                //Console.Write("Business Unit :- ");

                //foreach (var m in Enum.GetValues(typeof(BusinessUnit)))
                //{
                //    Console.WriteLine((int)m + " \t" + m);
                //}

                Console.Write("Project Type :- ");

                newProject.ProjectType = Console.ReadLine();


                Project_BL.InsertProject(newProject);

                Console.WriteLine("Project Record Inserted Successfully");
            }

            catch (ProjectException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Display()
        {

            try

            {
                List<Project.entity.Project> projectList

                  = Project_BL.DisplayProject();

                if (projectList.Count > 0)
                {

                    foreach (var project in projectList)

                    {
                        Console.WriteLine(project.ProjectId + "\t" + project.ProjectName+
                            "\t" + project.ClientName+"\t" + project.StartDate+"\t" 
                            + project.EndDate+"\t" + project.Status+"\t" 
                           + "\t" + project.ProjectType);
                    }

                }

                else

                    throw new ProjectException("Customer Records Unavailable");
            }

            catch (ProjectException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
