﻿using System;


namespace Project.Exception
{
    
      
    
        /// <summary>
        /// project Exception - User Defined Exception For Handling exceptions
        /// </summary>

        public class ProjectException : ApplicationException
        {

            public ProjectException()
            {

            }

            public ProjectException(string message) : base(message)
            {
                  
            }
        }
   }

