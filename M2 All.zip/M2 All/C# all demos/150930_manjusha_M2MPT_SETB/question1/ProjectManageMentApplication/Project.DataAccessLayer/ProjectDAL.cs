﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Project.entity;

namespace Project.DataAccessLayer
{

    public class ProjectDAL

    {

        public static List<Project.entity.Project> projectList
          = new List<Project.entity.Project>();

        public static void InsertProject(Project.entity.Project newProject)

        {


            try
            {

                FileStream fsObj = new FileStream
                  (@"D:\FileIO\project.txt", FileMode.Create);

                BinaryFormatter binaryObj = new BinaryFormatter();

                projectList.Add(newProject);

                binaryObj.Serialize(fsObj, projectList);

                Console.WriteLine("Serialization is SuccessFull...");

                fsObj.Close();
            }


            catch (SystemException ex) { throw ex; }
        }



        public static List<entity.Project> DisplayProject()

        {
            List<Project.entity.Project> projectList
              = new List<Project.entity.Project>();

            try
            {
                FileStream fsObj = new FileStream
                (@"D:\FileIO\project.txt", FileMode.Open);

                BinaryFormatter binaryObj = new BinaryFormatter();

                projectList = binaryObj.Deserialize(fsObj)
                  as List<entity.Project>;

                Console.WriteLine("DeSerialization....");

                fsObj.Close();
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return projectList;
        }
    }
}