﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.entity
{
    /// <summary>
    /// take all the details of the project related things
    /// </summary>
    [Serializable]
    //   enum BusinessUnit { Banking=1,TeleCommunication,E_Commerse };
    public class Project
    {
        public int ProjectId { get; set; }

        public string ProjectName { get; set; }

        public string ClientName { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string ProjectType { get; set; }

        public enum BusinessUnit
        {
            Banking = 1,
            Tele_Communication,
            E_Commerse
        }

        public string Status { get; set; }
    }

       
}

