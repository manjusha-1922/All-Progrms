﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Exception;
using System.Text.RegularExpressions;
using Project.DataAccessLayer;

namespace Project.BusinessLogicLyer
{
    public class Project_BL
    {
        public static bool ValidateProject
            (Project.entity.Project newProject)
        {
            StringBuilder message = new StringBuilder();

            bool validProject = true;

            try
            {
                if(newProject.ProjectId.ToString()==string.Empty)
                {
                    message.AppendLine("Project id should be provided");
                    validProject = false;
                }

                if(newProject.ProjectName==string.Empty)
                {
                    message.AppendLine("Project Name should be provided");
                    validProject = false;
                }

                else if (!Regex.IsMatch(newProject.ProjectName, "^[A-Z][a-z]+"))

                {
                    message.AppendLine("Project name should start with " +
                      "Capital letter and it " +
                      "should have alphabets only\n");

                    validProject = false;

                }

                if (newProject.ClientName == string.Empty)
                {
                    message.AppendLine("Client Name should be provided");
                    validProject = false;
                }
                else if (!Regex.IsMatch(newProject.ClientName, "^[A-Z][a-z]+"))

                {
                    message.AppendLine("Client name should start with " +
                      "Capital letter and it " +
                      "should have alphabets only\n");

                    validProject = false;

                }

                if (newProject.StartDate.ToString()==string.Empty)
                {
                    message.AppendLine("Start Date should be provided");
                    validProject = false;
                }
                else if(! (newProject.StartDate > DateTime.Now))

                {
                    message.AppendLine("start date shoud be greater than current date");

                    validProject = false;

                }
                if (newProject.EndDate.ToString() == string.Empty)
                {
                    message.AppendLine("End Date should be provided");
                    validProject = false;
                }
                else if (!(newProject.EndDate > DateTime.Now))

                {
                    message.AppendLine("End date should be greater than Current date");

                    validProject = false;

                }

                if (newProject.Status == string.Empty)
                {
                    message.AppendLine("Status of the project should be provided");
                    validProject = false;
                }
                else if(!(newProject.Status=="OnGoing" || newProject.Status=="Completed"))
                {
                    message.AppendLine("Status of the project should be provided ongoing or completed");
                    validProject = false;
                }

                if (newProject.ProjectType == string.Empty)
                {
                    message.AppendLine("Project Type should be provided");
                    validProject = false;
                }

                else if(!(newProject.ProjectType=="InternalProject" || newProject.ProjectType ==" ClientProject"))
                {
                    message.AppendLine("Project Type should be internal or client project");
                    validProject = false;
                }
                if (validProject == false)

                {
                    throw new ProjectException(message.ToString());
                }
            }

            catch (ProjectException ex)

            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return validProject;
        }


        public static void InsertProject
                    (Project.entity.Project newProject)
        {

            try
            {
                if (ValidateProject(newProject))
                {
                    ProjectDAL.InsertProject(newProject);
                }
                else
                    throw new ProjectException("Project data is invalid");
            }


            catch (ProjectException ex)
            {
                throw ex;
            }


            catch (SystemException ex)
            {
                throw ex;
            }
        }


        public static List<Project.entity.Project> DisplayProject()

        {

            List<Project.entity.Project> projectList = null;


            try
            {
                projectList = ProjectDAL.DisplayProject();
            }


            catch (ProjectException ex)
            {
                throw ex;
            }


            catch (SystemException ex)
            {
                throw ex;
            }


            return projectList;
        }
    }
}

