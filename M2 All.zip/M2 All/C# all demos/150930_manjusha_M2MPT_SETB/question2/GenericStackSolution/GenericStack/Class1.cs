﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericStack
{
    public class Stack
    {
        public static void stackFunc()
        {
            Stack<int> seqObj = new Stack<int>();
            seqObj.Push(1);
            seqObj.Push(2);
            seqObj.Push(3);
            seqObj.Push(4);

            Console.WriteLine("Print Sequence ");
            foreach (var seq in seqObj)
            {
                Console.WriteLine("\t" + seq);
            }
            //both peek and pop returns object the difference is pop returns and removes from list
            //where as peek just returns
            Console.WriteLine("The top most element from the stack is" + seqObj.Peek());

            Console.WriteLine("Removing top most element " + seqObj.Pop());

            Console.WriteLine("\n Print using for loop");
            int[] p = new int[seqObj.Count];

            //copy stack list to user created array
            seqObj.CopyTo(p, 0);
            for (int i = 0; i < seqObj.Count; i++)
            {
                Console.WriteLine("\t" + p[i]);
            }

            Console.WriteLine("\n print using forEach");
            foreach (var seq in seqObj)
            {
                Console.WriteLine("\t" + seq);
            }
        }



    }


    class CallingGenericFunction
    {
        static void Main(string[] args)
        {
            Stack.stackFunc();
        }
    }
}