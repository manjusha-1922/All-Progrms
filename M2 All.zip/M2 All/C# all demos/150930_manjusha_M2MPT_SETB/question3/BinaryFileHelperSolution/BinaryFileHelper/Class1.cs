﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_Io_Serialization_DeSerialization
{
    class BinaryFileHelper
    {
        static FileStream fsObj;
        #region write to binary file
        public static void WriteToFile()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(@"D:\FileIO\"); ;
            fsObj = new FileStream(directoryInfo.FullName + "binaryHelper.dat",
                FileMode.OpenOrCreate);

            BinaryWriter binaryWriterObj = new BinaryWriter(fsObj);

            //primitive data
            int age;
            string name;
            string gender;
            double height;
            int weight;



            Console.WriteLine("enter age ");
            age = int.Parse(Console.ReadLine());
            binaryWriterObj.Write(age);
            Console.WriteLine("enter name");
            name = Console.ReadLine();
            binaryWriterObj.Write(name);
            Console.WriteLine("enter gender");
            gender = Console.ReadLine();
            binaryWriterObj.Write(gender);
            Console.WriteLine("enter height");
            height = double.Parse(Console.ReadLine());
            binaryWriterObj.Write(height);
            Console.WriteLine("enter weight");
            weight = int.Parse(Console.ReadLine());
            binaryWriterObj.Write(weight);

            binaryWriterObj.Flush();
            binaryWriterObj.Close();
            fsObj.Close();

            Console.WriteLine("\n\tBinary Writing is successfull...!");

        }
        #endregion


        #region read from binary file
        //reading the data to the file

        public static void ReadFromFile()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(@"D:\FileIO\"); ;
            fsObj = new FileStream(directoryInfo.FullName + "binaryHelper.dat",
                FileMode.Open);

            BinaryReader binaryReaderObj = new BinaryReader(fsObj);

            int age1 = binaryReaderObj.ReadInt32();
            Console.WriteLine("Reading from a file age is " + age1);

            string name1 = binaryReaderObj.ReadString();
            Console.WriteLine("reading from a file name is" + name1);

            string gender1 = binaryReaderObj.ReadString();
            Console.WriteLine("Reading from a file gender is " + gender1);

            double height1 = binaryReaderObj.ReadDouble();
            Console.WriteLine("Reading from a file height is " + height1);

            int weight1 = binaryReaderObj.ReadInt32();
            Console.WriteLine("Reading from a file weight is " + weight1);


            binaryReaderObj.Close();
            fsObj.Close();
        }
        #endregion;
    }

    class Serializatoin
    {
        static void Main(string[] args)
        {
            BinaryFileHelper.WriteToFile();
            BinaryFileHelper.ReadFromFile();
        }
    }
}


