﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions ;
using System.IO;
using Entity;
using Exception;
using DataAccessLayer;
namespace BusinessLogicLayer
{
    public class ProductValidation
    {
        private static bool ValidateProduct(Product product)
        {

            bool validproduct = true;
            StringBuilder message = new StringBuilder();
            //if((product.ProductID <=0 )||(product.ProductID.ToString()==string.Empty))
            //{
            //validproduct=false;
            //    message.Append(Environment.NewLine+"Product ID Required and cannot be 0");
            //}
            ////Validating the Product ID for matching excatly with 6 digits
            //if(!(Regex.IsMatch(product.ProductID.ToString(),@"^[0-9]{6}$")))
            //{
            //    validproduct = false;
            //    message.Append(Environment.NewLine + "Product ID must contain 6 digits only");
            //}

            //if (!(Regex.IsMatch(product.ProductName, @"^[A-Z][a-z]+$")))
            //{
            //    validproduct = false;
            //    message.Append(Environment.NewLine + "ProductName must contain Characters only");
            //}

            if (!(Regex.IsMatch(product.Price.ToString(), @"^[0-9]+$")))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "Product Price must contain 6 digits only");
            }

            if ((product.Price.ToString().Equals(string.Empty)))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "Product Price is Required");
            }
            if (product.ProductName.Equals(string.Empty))
            {
                product.ProductName = "Unknown";
                //Product  product1 = new Product();
                //product.ProductName = product1.ProductName ;
            }
            else if (product.ProductName != null)
            {
                if (product.ProductName == "TV" || product.ProductName == "Mobile")
                { validproduct = true; }
                else
                {
                    message.Append(Environment.NewLine + "Product Name must be either TV or Mobile");
                    validproduct = false;
                }
            }
            if (validproduct == false)
            {
                throw new ProductException(message.ToString());
            }
            return validproduct;
            }

        /// <summary>
        /// To validate the Product and to add the Product to Collection List by 
        /// calling the AddProduct method of DAL
        /// </summary>
        /// <param name="product"></param>
        /// <returns>Bool</returns>
        public static bool AddProductBL(Product product)
        { 
            bool productadded=false;
            try
            {
                if (ValidateProduct(product))
                {
                    productadded = DataAccessLayer.ProductOperations.AddProduct(product);

                }
            }
            catch (ProductException)
            { throw; }
        return productadded;
        }
        //Function to Display all products from Collection
        public static List<Product> DisplayAllProductBL()
        {
            ProductOperations operationsobj = new ProductOperations();
            List<Product >plist = new List<Product>();
            try
            {
                plist = operationsobj.DisplayProducts();
                if (plist == null)
                    throw new ProductException("No Product Found");
            }
            catch (ProductException )
            {
                throw;
            }
           
                return plist; // Returns the list of Products
      
        }
        //Function to save the product list to file using Serialization
        public static void SerializeProductBL()

        {
            try
            {
                DataAccessLayer.ProductOperations.SerializeProduct();
            }
            catch (ProductException e)
            { throw e; }
            catch (IOException e)
            {
                throw e;
            }
        }
        //Function to display the products from File using Deserialization
        public static List<Product> DeSerializeProductBL()
        {
            List<Product> deserializedlist = new List<Product >();

            try
            {
                deserializedlist = DataAccessLayer.ProductOperations.DeserializeProduct();
                if (deserializedlist.Count > 0)
                    return deserializedlist;
                else
                    throw new ProductException("No Records in File");
            }

            catch (IOException e)
            {
                throw e;
            }
            catch (SystemException e)
            { throw e; }
        }
        //Function to search Product Info using Product ID
        public static Product SearchProduct(int productID)
        {
            Product productSearched = null;

            try
            {
                //Searching Product
                productSearched = ProductOperations.SearchProduct(productID);

                //If searched Product is null raise exception
                if (productSearched == null)
                {
                    throw new ProductException("Product Info does not exist!");
                }
            }
            catch (ProductException p)
            {
                throw;
            }
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }

            return productSearched;
        }
    }
}
