﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    /// <summary>
    /// Creating Custom Attibute for Product Category
    /// Multiple Category Types can be defined while creating the Product
    /// </summary>
    [AttributeUsage( AttributeTargets.Class,AllowMultiple =true)]
  public  class ProductAttribute:Attribute 
    {
        
        public string CategoryType { get; set; }
        public ProductAttribute(string cattype)
        {
            CategoryType = cattype;
        }
    }
}
