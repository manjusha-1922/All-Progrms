﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    /// <summary>
    /// Entity Class with Product members declared
    /// Author:"Sangeetha"
    /// Date of Creation:10-Mar-2016
    /// </summary>
    /// 
   [Serializable]
    [ProductAttribute("InStock")] // Assigning the Category Type to Product
   [ProductAttribute("Featured Discount")]
   [ProductAttribute("No COD Available")]
    public class Product
    {

        public int ProductID { get; set; }//Gets or Sets ProductID
        public string ProductName { get; set; }
        public float Price { get; set; }

        public Product()
        {
            ProductID = 0;
            ProductName = "UnKnown";
            Price = 0;
        }

    }

    
}
