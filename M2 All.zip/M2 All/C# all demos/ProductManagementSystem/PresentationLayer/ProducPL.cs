﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Entity;
using Exception;
using DataAccessLayer;
using BusinessLogicLayer;

namespace PresentationLayer
{
    class ProducPL
    {
       static Random autoid = new Random(1);
        public static int AutoId()
        {   
         return (autoid.Next(1,1000));
        }
       
        //Method to Add a Product and calling the validation methods from the ProductBL class
        public static void AddProduct()
        {
           
            try
            {
                //Creating object of Product class to access the values being stored through the properties
                Product newproduct = new Product();
                bool chkprice;
                int pid,price;
                //User Inputs
                #region [obsolete]
                /* Console.Write("Enter Product ID : ");
                chkid = Int32.TryParse(Console.ReadLine(), out pid);
                if (chkid)
                    newproduct.ProductID = pid;
                else throw new ProductException("Enter a Valid Product ID");
                */
                #endregion

               
                newproduct.ProductID =AutoId();
                Console.Write("Enter Product Name : ");
                newproduct.ProductName= Console.ReadLine();
                

                Console.Write("Enter Product Price : ");
                chkprice = Int32.TryParse(Console.ReadLine(), out price );
                if (chkprice)
                    newproduct.Price  = price;
                else throw new ProductException("Enter a Valid Price");

                //Checking the Validation of User I/P and 
                //adding the product to list by calling the BL method
                
                bool productadded = ProductValidation.AddProductBL(newproduct);
                if (productadded == true)
                    Console.WriteLine("Product Details Added to the List Successfully");
                else
                   // Console.WriteLine("Sorry!! Product Details are not added");
                    throw new ProductException("Product not Added!");

   
            }
            //Catching user defined exception
            catch (ProductException p)
            {
                Console.WriteLine(p.Message);
            }

                //Catching System exception
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
        }

//Method to Display the Product Details from the Collection 


        public static void DisplayProduct()
        {
            //Creating List object to store n number of inputs from the user
            List<Product> productList = new List<Product>();

            try
            {
                productList = ProductValidation.DisplayAllProductBL ();
                if (productList.Count > 0)
                {
                    Console.WriteLine("**************All Product Detail***********");
                    Console.WriteLine("Product ID      Product Name   Product Price");
                    Console.WriteLine("---------------------------------------------");
                    foreach (Product prod in productList)
                    {

                        Console.WriteLine("--- {0} ---\t--- {1} ---\t--- {2} ---\t", prod.ProductID, prod.ProductName, prod.Price);
                    
                    }
                    Attribute[] prAttr = Attribute.GetCustomAttributes(typeof(Entity.Product),typeof(ProductAttribute));
                    Console.WriteLine("Category Descriptions:");
                    foreach (ProductAttribute pa in prAttr)
                    {
                        
                       
                    ProductAttribute  pr = (ProductAttribute)pa;
                             Console.WriteLine(pr.CategoryType.ToString());
                    }

                }
                else
                {
                    throw new ProductException("There are no records!");
                }
            }
            //Catching User defined exception
            catch (ProductException p)
            {
                Console.WriteLine(p.Message);
            }
            //Catching System exception
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void SearchProduct()
        {
            int prodID;
            Product searchedProduct;

            try
            {
                Console.Write("Enter Product ID for search : ");
                prodID = Convert.ToInt32(Console.ReadLine());

                //Checking if all validations by calling the ProductBiz class to use it's function AND using are true AND using NAMED ARGUMENTS
                searchedProduct = ProductValidation.SearchProduct(productID: prodID);//using Named argument

                if (searchedProduct != null)
                {
                    Console.WriteLine("Product ID   : " + searchedProduct.ProductID);
                    Console.WriteLine("Product Name : " + searchedProduct.ProductName);
                    Console.WriteLine("Product Price: " + searchedProduct.Price);
                }

                else
                {
                    throw new ProductException("Product not found!");
                }
            }
            //Catching User defined exception
            catch (ProductException p)
            {
                Console.WriteLine(p.Message);
            }
            //Catching System exception
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void SerializePL()
        {
            try
            {
                ProductValidation.SerializeProductBL();
                Console.WriteLine("Data Serialized and saved to File");
            }
            catch (ProductException p)
            { Console.WriteLine(p.Message); }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
           
        }
        public static void DeserializePL()
        {
            List<Product> productList = new List<Product>();
            try
            {
                productList = ProductValidation.DeSerializeProductBL();
                if (productList.Count != 0)
                {

                    foreach (Product product in productList)
                    {
                        Console.WriteLine("Product ID   :{0}", product.ProductID);
                        Console.WriteLine("Product Name :{0}", product.ProductName);
                        Console.WriteLine("Product Price:{0}", product.Price);

                    }
                }
                else Console.WriteLine("No Records Found");

            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (SystemException e)
            { Console.WriteLine(e.Message); }

        
        }
            //Method to print menu to the user for user's choice
        public static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("*****Product Management System*************");
            Console.WriteLine("1.  To Add Product Details  - Press 1,");
            Console.WriteLine("2.  To Display All Products - Press 2,");
            Console.WriteLine("3.  To Search a Product     - Press 3,");
            Console.WriteLine("4.  To Serialize Data       - Press 3,");
            Console.WriteLine("5.  To Deserialize Data     - Press 4,");
            Console.WriteLine("6.  To Exit the Application - Press 5,");
            Console.WriteLine("*********************************************");
        }

        static void Main(string[] args)
        {
            int userchoice;
            bool chkchoice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice from the Menu");
                chkchoice = Int32.TryParse(Console.ReadLine(), out userchoice);
                if (!chkchoice)
                    Console.WriteLine("Enter a Valid Choice from the Menu");
                else
                    switch (userchoice)
                    {
                        case 1: AddProduct();
                            break;
                        case 2: DisplayProduct();
                            break;
                        case 3: SearchProduct();
                            break;
                        case 4: SerializePL();
                            break;
                        case 5: DeserializePL();
                            break;
                        case 6: break;
                        default: Console.WriteLine("Invalid Choice");
                            break;

                    }
            } while (userchoice != 6);

        }
    }
    }

