﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Entity;
using Exception;

namespace DataAccessLayer
{
    public class ProductOperations:IProduct
    {
      public static List<Product> productlist = new List<Product>();

        public static bool AddProduct(Product newproduct)
        {
            bool productadded = false;
            try
            {
                productlist.Add(newproduct);
                productadded = true;
            }

            catch (ProductException )
            { throw ; }
            return productadded;
        }
        //Implementing DisplayProducts method of IProduct Interface
        public  List<Product> DisplayProducts()
        {
                return productlist;
           
        }

        public static void SerializeProduct()
        {
            try
            {
                if (productlist.Count != 0)
                {
                    FileStream file = new FileStream("Product.txt", FileMode.Append, FileAccess.Write);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(file, productlist);
                    file.Close();
                }
                else
                    throw new ProductException("No Data to be Serialized");
            }
            catch (ProductException)
            {
                throw;
            }
            catch (IOException )
            {

                throw ;
            }
        
        
        }
        public static List<Product> DeserializeProduct()
        {
            List<Product> productlist1 = new List<Product>();
           // Product prod = new Product();
            try
            {

                FileStream file = new FileStream("Product.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter formatter = new BinaryFormatter();
                productlist1 = (List<Product>)formatter.Deserialize(file);
                file.Close();
            }
            catch (IOException e)
            {
                throw ;
            }
            catch (SystemException e)
            {
                throw ;
            }

            return productlist1;
        }
        public static Product  SearchProduct(int prodID)
        {
            try
            {
                //Searching the product using Lambda expressions.
                
                Product searchedproduct = productlist
                                            .Find(p => p.ProductID == prodID);//null;

                //Return the details of searched Product
                return searchedproduct;
            }
            catch (ProductException )
            {
                throw;
            }
        }
        


    }
}
