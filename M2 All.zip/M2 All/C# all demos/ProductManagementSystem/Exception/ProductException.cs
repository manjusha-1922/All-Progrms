﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exception
{

    /// <summary>
    /// To Create Custom Exception class for throwing and Handling the Exceptions
    /// </summary>
    public class ProductException:ApplicationException 
    {
        public ProductException() 
            : base()
        { }
        public ProductException(string errormsg) 
            : base(errormsg)
        { }
        public ProductException(string errormsg, System.Exception innerexception)
            : base(errormsg, innerexception)

        { }

    }
}
