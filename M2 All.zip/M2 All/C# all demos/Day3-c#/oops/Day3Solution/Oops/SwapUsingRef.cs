﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class Number
    {
        public static void Swap(ref int a,ref int b)
        {
            a = a + b;
            b = a - b;
            a = a - b;
        }
    }
    class SwapUsingRef
    {
        static void Main(string[] args)
        {
            int a, b;
            a = 10;
            b = 20;
            Console.WriteLine("Before swap : a= " +a +"b = "+b);
            Number.Swap( ref a,ref  b);
            Console.WriteLine("After swap : a= " + a + "b = " + b);
        }
    }
}
