﻿using System;
using OopsLibrary;

namespace Oops
{
    class Partialclass_Example
    {
        static void Main(string[] args)
        {
            Rectangle rectobj = new Rectangle();
            rectobj.AreaOfRectangle();
        }
    }
}
