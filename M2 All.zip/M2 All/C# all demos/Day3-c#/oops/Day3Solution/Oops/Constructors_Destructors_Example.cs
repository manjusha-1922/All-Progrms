﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class Constructors_Destructors_Example
    {
        static void Main(string[] args)
        {
            new LifeCycleOfObject().display();
            Console.WriteLine("After calling display function");
                
        }
    }
}
