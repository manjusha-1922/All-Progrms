﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    struct OrderDetails
    {
        int orderId;
        string custName;
        string prodName;
        float price;

        public OrderDetails(int orderId, string custName, string prodName, float price)
        {
            this.orderId = orderId;
            this.custName = custName;
            this.prodName = prodName;
            this.price = price;
        }

        public int OrderId
        {
            get
            {
                return orderId;
            }

            set
            {
                orderId = value;
            }
        }

        public string CustName
        {
            get
            {
                return custName;
            }

            set
            {
                custName = value;
            }
        }

        public string ProdName
        {
            get
            {
                return prodName;
            }

            set
            {
                prodName = value;
            }
        }

        public float Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }

        //private object obj;






        public void display(OrderDetails obj)
        {
            Console.WriteLine("Order details are...");
            Console.WriteLine("Order Id : "+obj.OrderId);
            Console.WriteLine("Cust Name : "+obj.CustName);
            Console.WriteLine("Product Name : "+obj.ProdName);
            Console.WriteLine("Product Price : "+obj.Price);
        }

        class StructExample
        {

            static void Main(string[] args)
            {
                OrderDetails obj = new OrderDetails();
                obj.OrderId = 10001;
                obj.CustName = "Akhil";
                obj.ProdName = "abc";
                obj.Price = 1000;

            }
        }
    }
}