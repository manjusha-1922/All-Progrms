﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class InterfaceExample
    {
        static void Main(string[] args)
        {
            Customers custObj = new Customers(101,"ABC",10000000,10000);

            
            IHDFCBank hdObj = custObj;
            hdObj.OpenAccount();
            hdObj.Deposit();

            IAxisBank aObj=custObj;
            aObj.openAccount();
            aObj.ShowBalance();

        }
    }
}
