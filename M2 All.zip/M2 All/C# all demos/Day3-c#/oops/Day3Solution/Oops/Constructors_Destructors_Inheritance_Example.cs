﻿using System;

namespace Oops
{
    class Constructors_Destructors_Inheritance_Example
    {
        static void Main(string[] args)
        {
            Derieved derievedobj = new Derieved();
        }
    }
}
