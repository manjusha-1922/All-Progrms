﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class MonitorExample
    {
        static void Main(string[] args)
        {
            new Monitor();
            Monitor.Print('A');
            Monitor.Print("Manju");
            Monitor.Print(10);
        }
    }
}
