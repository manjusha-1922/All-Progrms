﻿using System;
using OopsLibrary;

namespace Oops
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Radius :- ");
            float radius = float.Parse(Console.ReadLine());


            Shape shapeCircle = new Shape(radius);
           // Shape shapeCircle = new Shape(2f);
            float area = shapeCircle.CalculateAreaOfCircle();
            Console.WriteLine("Area of circle is :" +area);

            Console.WriteLine("Side :-");
            int side = int.Parse(Console.ReadLine());

            Shape shapeSquare = new Shape(side);
           // Shape shapeSquare = new Shape(3);
            area = shapeSquare.CalculateAreaOfSquare();
             Console.WriteLine("Area of Square is :" + area);

        }

    }
}
