﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class WriteOnlyPropertyExample
    {
        static void Main(string[] args)
        {
            //obj initializer
            Customer customerObj = new Customer
            {
                CId = 1,
                Name = "ABC",
                Address = "Mumbai"
            };
            customerObj.display();
        }
    }
}
