﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class ReadOnlyPropertyExample
    {
        static void Main(string[] args)
        {
            //object initilizer
            /* Employee employeeObj = new Employee
             {
                 EId = 1,
                 Name = abc
             };*/

            //property initilizer
            /*Employee employeeObj = new Employee();
            employeeObj.EId = 1;
            employeeObj.Name = "abc";*/


            //constructor initializer
            Employee employeeObj = new Employee(EId: 1, Name: "Mukund");
            Console.WriteLine("EId is "+employeeObj.EId);
            Console.WriteLine("Name is "+employeeObj.Name);

        }
    }
}
