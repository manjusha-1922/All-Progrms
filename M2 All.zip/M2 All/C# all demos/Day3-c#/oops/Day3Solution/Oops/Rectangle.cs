﻿using System;

namespace Oops
{
    internal class Rectangle
    {
        internal void AreaOfRectangle()
        {
            throw new NotImplementedException();
        }
    }
}