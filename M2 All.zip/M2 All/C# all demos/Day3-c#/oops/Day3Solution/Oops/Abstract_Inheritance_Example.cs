﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static OopsLibrary.Employees;

namespace Oops
{
    class Abstract_Inheritance_Example
    {
        static void Main(string[] args)
        {
            Employees managerObj = new Manager(101, "abc", 25000, "IT");
            Console.WriteLine(managerObj.Display());
        }
    }
}
