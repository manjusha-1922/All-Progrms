﻿using System;


namespace Oops
{
    class ParameterTypes
    {
        //call by value shares copy of the variable
        //change will not be reflected in calling section
        public static int show(int i)
        {
            i = 10;
            return i;
        }
        //call by reference shares address of the variables
        //so original value will be modified in calling section
        //it acts as both in put and output parameter
        //while calling u can.t omit initilization to the variable
        public static void showA(ref int a)
        {
            a = a + 20;
        }
        //call by output parameter - shares address of the variable
        //it acts only as output parameter
        //result will be stored in output variable and value
        //will be returned to calling section
        //no need of initilization to the variable,when calling function
        //with the parameter
        public static void ShowB(out int b)
        {
            b = 25;
        }
    }

    class ParameterTypesExample
    { 
        static void Main(string[] args)
        {

            int i = 10;

            Console.WriteLine("Before Output of parametersTypes.show(10) is "+i );
            ParameterTypes.show(i);
            Console.WriteLine("\nAfter Output of parametersTypes.show(10) is "+i);

            int a = 10;
            Console.WriteLine("Reference Type - input and output parameter");
            Console.WriteLine("Before Output of parametersTypes.showA(a) is" + a);
            ParameterTypes.showA(ref a);
            Console.WriteLine("\nAfter Output of parametersTypes.show(a)"+a);

            int b ;
            Console.WriteLine("Output Type - Output parameter");
      //      Console.WriteLine("Before Output of parametersTypes.show(b)" + b);
            ParameterTypes.ShowB(out b);
            Console.WriteLine(" \nAfter output of parametersTypes.show(10)" + b);
        }
    }

}
