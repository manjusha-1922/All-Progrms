﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class ShapeAbstractExample
    {
        static void Main(string[] args)
        {
            Shapes shapeObj1 = new circle(2f);
            shapeObj1.CalculateArea();
            Shapes shapeObj2 = new Square(2);
            shapeObj2.CalculateArea();

        }
    }
}
