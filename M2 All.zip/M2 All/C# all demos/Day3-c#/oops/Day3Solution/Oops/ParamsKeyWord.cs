﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class Calculator
    {
        public static float addition(params float[] nums)
        {
            float sum = 0;
            foreach(var n in nums)
            {
                sum += n;
            }
            return sum;
        }
    }
    class ParamsKeyWord
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculator.Addition(10) :"+Calculator.addition(10));
            Console.WriteLine("Calculator.Addition(10,20,30) :" + Calculator.addition(10,20,30));
            Console.WriteLine("Calculator.Addition(10,15,20,30,40,50) :" + 
                Calculator.addition(10,15,20,30,40,50));
        }
    }
}
