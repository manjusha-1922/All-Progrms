﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class StaticClass
    {
        int i; //instance variable
        static int b; //class variable or static variable
        //non static function - static and non static
        public void show()
        {
            Console.WriteLine("From show function i: "+i);
            Console.WriteLine("From show function b: "+b);
        }

        //static function only static members are allowed

        public static void show1()
        {
            Console.WriteLine("from show1 function"+b);
        }

        //non static constructor - static and non static

        public StaticClass()
        {
            Console.WriteLine("\nNon static constructor");
            i = 10;
            b = 20;
            Console.WriteLine("value of i: "+i);
            Console.WriteLine("value of b: "+b);
           
        }
        static StaticClass()
        {
            Console.WriteLine("static constructor");
            Console.WriteLine("b: "+b);
            b = 20;
            Console.WriteLine("b: " + b);
        }
        static void Main(string[] args)
        {
            StaticClass obj = new StaticClass();
            obj.show();
            StaticClass.show1();
        }
    }
}
