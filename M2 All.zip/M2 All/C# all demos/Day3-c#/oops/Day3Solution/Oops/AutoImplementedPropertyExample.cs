﻿using OopsLibrary;
using System;


namespace Oops
{
    class AutoImplementedPropertyExample
    {
        static void Main(string[] args)
        {
            //property initializer
            Product productObj = new Product();
            Console.WriteLine("Product Name : ");
            productObj.ProductName = Console.ReadLine();
            Console.WriteLine("Product Qty : ");
            productObj.Quantity = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Product Price : ");
            productObj.Price = float.Parse(Console.ReadLine());

            Console.WriteLine("Below given are product details");
            Console.WriteLine("Product Name : " + productObj.ProductName);
            Console.WriteLine("Product Qty : " + productObj.Quantity);
            Console.WriteLine("Product Price : " + productObj.Price);
            Console.WriteLine("---------------------------------------------");
            float totalPrice = productObj.Quantity * productObj.Price;
            Console.WriteLine("Total Price :- " + totalPrice);


            //object initializer
            Product product = new Product
            {
                ProductName = "abc",
                Quantity = 1,
                Price = 25000

            };

            Console.WriteLine("Below given are product details");
            Console.WriteLine("Product Name : " + product.ProductName);
            Console.WriteLine("Product Qty : " + product.Quantity);
            Console.WriteLine("Product Price : " + product.Price);
            Console.WriteLine("---------------------------------------------");
           totalPrice = productObj.Quantity* productObj.Price;
           Console.WriteLine("Total Price :- " + totalPrice);

           /* Product product1 = new Product()
            {
                ProductName=Camera
            };*/
        }
    }
}



