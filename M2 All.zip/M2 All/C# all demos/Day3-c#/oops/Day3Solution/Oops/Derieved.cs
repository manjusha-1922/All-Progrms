﻿namespace Oops
{
    internal class Derieved
    {
    }
}