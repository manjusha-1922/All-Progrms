﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class ReadWritePropertyExample
    {
        public static object Cndidate { get; private set; }

        static void Main(string[] args)
        {
            Candidate candidateObj = new Candidate();
            Console.WriteLine("Type your name here :- ");
            candidateObj.Name = Console.ReadLine();

            Console.WriteLine("Type your age here :- ");
            candidateObj.Age = int.Parse(Console.ReadLine());

            Console.WriteLine("\nYour name is "+candidateObj.Name);
            if(candidateObj.Age==-1)
            {
                Console.WriteLine("Error: Age must be between 18 and 40");
            }
            else
            {
                Console.WriteLine("Your Age is "+candidateObj.Age);
                Console.WriteLine("You are alpgible to participate "+ "in the event");
            }
        }
    }
}
