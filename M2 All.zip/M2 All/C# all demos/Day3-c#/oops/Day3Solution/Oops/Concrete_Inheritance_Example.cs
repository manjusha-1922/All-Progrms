﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class Concrete_Inheritance_Example
    {
        static void Main(string[] args)
        {
            //Example 1:

           /* Manager managerObj = new Manager(101, "abc", 25000, "IT");
            Console.WriteLine(managerObj.Display());*/

            //Example 2 : Function over riding using dynamic polymorphism

           // Employees managerObj = new Manager(101, "abc", 25000, "IT");
          //  Console.WriteLine(managerObj.Display());
        }
    }
}
