﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class DifferentTypesExample
    {
        static void Main(string[] args)
        {
            DifferentTypes Obj = new DifferentTypes();
            Obj.ValueTypes();
            Obj.ObjectType();
            Obj.ReferenceTypes();
            Obj.NullableTypes();
            Obj.varType();
            Obj.DynamicType();
            Obj.AnonymousTypes();
        }
    }
}
