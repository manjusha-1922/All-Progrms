﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    enum Months {  January=1, February, March, April, May, June, July, August, September, October, November, December};
    class EnumExample
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menu :- ");
            foreach(var m in Enum.GetValues(typeof(Months)))
                {
                Console.WriteLine((int)m+" \t"+m);
            }
        }
    }
}
