﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class Demo
    {
        protected int i = 20;
    }
    class MyClass : Demo
    {
        int i = 5;

        public void Display(int i)
        {
            Console.WriteLine("i = " + i);
            Console.WriteLine("this.i = " + this.i);
            Console.WriteLine("base.i = " + base.i);
        }
    }

    class This_Base_KeyWordExample
    { 
        static void Main(string[] args)
        {
            MyClass m = new MyClass();
            m.Display(30);
        }
    }
}
