﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    public static class Utility
    {
        public static int WordCount(this string sentence)
        {
            return sentence.Split(new char[] { ' ' }).Length;
        }
    }
    class ExtensionMethods
    {
        static void Main(string[] args)
        {
            string name = "my name is abc";
            Console.WriteLine(name);
            Console.WriteLine("Word count is " +name.WordCount());
        }
    }
}
