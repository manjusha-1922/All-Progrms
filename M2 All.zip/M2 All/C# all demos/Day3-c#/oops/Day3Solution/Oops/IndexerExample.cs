﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class Indxer
    {
        private string[] myData;
        public  Indxer(int size)
        {
            myData = new string[size];
        }
        public string this[int pos]
        {
            get { return myData[pos]; }
            set { myData[pos] = value; }
        }
        public string Display()
        {
            StringBuilder str = new StringBuilder();
            for(int i=0;i<10;i++)
            {
                str.AppendLine(myData[i]);
            }
            return str.ToString();
        }
    }
    class IndexerExample
    {
        static void Main(string[] args)
        {
            int size = 10;
            Indxer myind = new Indxer(size);
            myind[3] = "some value";
            myind[1] = "another value";
            myind[2] = "other value";
              Console.WriteLine(myind.Display());
           // myind.Display();
        }
    }
}
