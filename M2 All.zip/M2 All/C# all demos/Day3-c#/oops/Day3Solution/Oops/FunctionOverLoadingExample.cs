﻿using OopsLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    class FunctionOverLoadingExample
    {
        static void Main(string[] args)
        {
            Calculator calculateObj = new Calculator();
          //  Console.WriteLine("Addition : " +calculateObj.Operation(2,3));
            //Console.WriteLine("Multiplication : "+calculateObj.Operation(2f,3f));
        }
    }
}
