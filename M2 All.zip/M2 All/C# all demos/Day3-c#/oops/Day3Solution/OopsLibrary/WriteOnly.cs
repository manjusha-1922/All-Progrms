﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    public class Customer
    {
        public int CId { private get; set; }

        public string Name { private get; set; }

        //write only property with variable
        string address;

        public string Address {
            set
            {

           address = value;
            }
         }
             public void display()
        {
            Console.WriteLine("CId is " + CId);
            Console.WriteLine("Name is " + Name);
            Console.WriteLine("Address is " + address);
        }

    }

}
