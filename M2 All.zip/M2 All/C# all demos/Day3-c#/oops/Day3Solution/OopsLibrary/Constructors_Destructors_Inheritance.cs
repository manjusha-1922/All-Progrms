﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    public class Base
    {
        public Base()
        {
            Console.WriteLine("Base class constructor");
        }
        ~Base()
        {
            Console.WriteLine("Base class destructor");
        }

        public class Derieved : Base
        {
            public Derieved()
            {
                Console.WriteLine("Derived class constructor");
            }
            ~Derieved()
            {
                Console.WriteLine("Derived class destructor");
            }
        }
    }
}
