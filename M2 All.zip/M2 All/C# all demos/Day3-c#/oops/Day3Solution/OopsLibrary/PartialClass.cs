﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    partial class Rectangle
    {
        public float length { get; set; }

        public float breadth { get; set; }
    }
   partial class Rectangle
    {
        public float AreaOfRectangle()
        {
            float area = length * breadth;
            return area;
        }
    }
}
