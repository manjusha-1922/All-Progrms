﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
   public class Monitor
    {
       public static void Print(char val)
        {
            Console.WriteLine(val);
        }
       public static void Print(int val)
        {
            Console.WriteLine(val);
        }
     public   static void Print(string val)
        {
            Console.WriteLine(val);
        }
    }
}
