﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
  public  class LifeCycleOfObject
    {
        public LifeCycleOfObject()
        {
            Console.WriteLine("Constructor Called..");
        }
        
        ~ LifeCycleOfObject()
        {
            Console.WriteLine("Destructor called..");
        }

        public void display()
        {
            Console.WriteLine("display called...");
        }
    }
 }

