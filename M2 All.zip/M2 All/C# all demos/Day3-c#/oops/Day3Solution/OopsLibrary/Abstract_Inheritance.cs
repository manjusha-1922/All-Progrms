﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    public abstract class Employees
    {
        protected int eId;
        protected string name;
        protected float salary;


        public Employees(int eId, string name, float salary)
        {
            this.eId = eId;
            this.name = name;
            this.salary = salary;
        }

        public abstract string Display();




        public class Manager : Employees
        {
            string deptName;
            public Manager(int eId, string name, float salary, string deptName) : base(eId, name, salary)
            {
                this.deptName = deptName;
            }
            public override string Display()
            {

                StringBuilder strObj = new StringBuilder();
                strObj.AppendFormat("Eid is {0}", eId);
                strObj.AppendLine();
                strObj.Append("Name is " + name + "\n");
                strObj.Append("salary is " + salary + " \n");
                //strObj.Append("")
                strObj.Append("Departmenyt Name is " + deptName);

                return strObj.ToString();

            }
        }
    }
}
