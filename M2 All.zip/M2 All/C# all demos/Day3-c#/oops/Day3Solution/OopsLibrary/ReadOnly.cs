﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    //read only property requires compulsory constructor
   public class Employee
    {
        public int EId { get; set; }

        public string Name { get;  }

        public Employee(int EId, string Name)
        {
            this.EId = EId;
            this.Name = Name;

        }
    }
}
