﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    public class Calculator
    {
        public int Operation(int a,int b)
        {
            return a + b;
        }
        public float Operation(float a,float b)
        {
            return a * b;
        }
    }
}
