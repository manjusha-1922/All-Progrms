﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    public interface IHDFCBank
    {
        
        void Deposit();
        void OpenAccount();
    }
    public interface IAxisBank
    {
        
        void ShowBalance();
        void openAccount();
    }
   public class Person
    {
        protected int Id;
        protected string name;
    }
   public class Customers : Person,IHDFCBank,IAxisBank
    {
        int accountNumber;
        float balance;

        public Customers(int Id,string name,int accountNumber,float balance)
        {
            this.Id = Id;
            this.name = name;
            this.accountNumber = accountNumber;
            this.balance = balance;
        }

        public void Deposit()
        {
            Console.WriteLine("Deposited");
        }

         void IHDFCBank.OpenAccount()
        {
            Console.WriteLine("HDFC account opened successfully"); 
        }

         void IAxisBank.openAccount()
        {
            Console.WriteLine("Axis Bank account opened successfully");
        }

        public void ShowBalance()
        {
            Console.WriteLine("Balance:"); ;
        }
    }
}
