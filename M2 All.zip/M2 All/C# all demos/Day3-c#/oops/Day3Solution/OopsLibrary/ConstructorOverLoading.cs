﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    //constructor over loading
    public class Shape
    {
        float radius;
        int side;
        //default constructor exist by default
        /*   Shape()
           {

           }*/

        //Circle

        public Shape(float radius)//parameterised constructor
        {
            this.radius = radius;
        }

        //square
        public Shape(int side)//parameterised constructor
        {
            this.side = side;
        }


        public float CalculateAreaOfCircle()
        {
            float area = (float)Math.PI * radius * radius;
            return area;
        }

        public int CalculateAreaOfSquare()
        {
           int area = side * side;
            return area;
        }
        //destructor can not be public
        //only one destructor per class
        //will be executed automatically when object goes out of scope
        ~Shape()
        {

            Console.WriteLine("destructor called.........");
            radius = 0;
            side = 0;
        }
    }
}