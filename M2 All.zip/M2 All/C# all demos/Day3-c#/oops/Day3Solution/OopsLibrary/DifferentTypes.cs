﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
   public class DifferentTypes
    {
        //value types - instance variables
        byte b;
        short s;
        int i;
        long l;
        float f;
        double d;
        char c;
        bool bo;

        //strongly typed
        public void ValueTypes()
        {
            Console.WriteLine("byte b = "+b+"sizeof(byte) is"+sizeof(byte));
            Console.WriteLine("short s = " + s + "sizeof(short) is" + sizeof(short));
            Console.WriteLine("int i = " + i + "sizeof(int) is" + sizeof(int));
            Console.WriteLine("long l = " + l + "sizeof(long) is" + sizeof(long));
            Console.WriteLine("float f = " + f + "sizeof(float) is" + sizeof(float));
            Console.WriteLine("double d = " + d + "sizeof(double) is" + sizeof(double));
            Console.WriteLine("char c = " + c + "sizeof(char) is" + sizeof(char));
            Console.WriteLine("bool bo = " + bo + "sizeof(bool) is" + sizeof(bool));
        }

        //it is loosly typed
        object obj;
        public void ObjectType()
        {
            Console.WriteLine("Default value of obj "+obj);
            obj = 15; //here it is integer type
            Console.WriteLine("obj = 15 " + obj);
            obj = 2000.00;
            //unboxing
            double d = (double)obj;
            Console.WriteLine("obj = 2000.00 " + obj);
            obj = "Manjusha";
            Console.WriteLine("obj= manjusha " + obj);
            obj = new int[] { 10, 20, 30, 40, 50 };
            Console.WriteLine(" obj = new int[] { 10, 20, 30, 40, 50 } " + obj);
            obj = false;
            Console.WriteLine("obj = false " + obj);
        }

        //reference types
        public void ReferenceTypes()
        {
            int num1, num2;
            num1 = num2 = 10;
            if (num1 == num2)
            {
                Console.WriteLine("Both are equal");
            }
            else
                Console.WriteLine("Both are not equal");

            string str1, str2;

            str1 = str2 = "manjusha";
            if(str1==str2)
                Console.WriteLine("Both are equal");
            else
                Console.WriteLine("Both are not equal");


            DifferentTypes obj1 = new DifferentTypes();
            DifferentTypes obj2 = new DifferentTypes();
            obj1 = obj2;
            if (obj1 == obj2)
                Console.WriteLine("Both are equal");
            else
                Console.WriteLine("Both are not equal");

        }
        //taking null values in primitive types [?]

        public void  NullableTypes()
        {
            int? num = null;
            int x = 0; //local variables
            Console.WriteLine("num is "+ num);

            //[??] - NullCoa;esce operator
            //it is used to check null in primitive types

            x = num ?? 10;
            Console.WriteLine("num is "+ num);
            Console.WriteLine("x is " +x);
        }

        //var type - implecitly typed

        public void varType()
        {
            var b = 10;
            int i = b;
            Console.WriteLine("b is " + b);
        }

        //Dynamic type - DLR [dynamic  Lang Runtime]
        //not recommended all the the times
        //dynamic is run time type safe
        public void DynamicType()
        {
            dynamic d = 10;
            int i = d;
            Console.WriteLine("d "+d);
            Console.WriteLine("i "+i);


            d = "Hello";
            string str = d;
            Console.WriteLine("d " + d);
            Console.WriteLine("str " + str);


            d = false;
            bool b = d;
            Console.WriteLine("d "+d);
            Console.WriteLine("b "+b);
        }

        //creating objects with out creating class
        //creating temporary objects
        //it is used in case if u dont want reuse ur class
        //if u dont want to add functions
        public void AnonymousTypes()
        {
            var emp1 = new
            {
                FirstName = "Manjusha",
                LastName = "Gudiwada",
                Age = 20,
                Address = "Guntur"

            };
            Console.WriteLine(emp1.FirstName+" "+emp1.LastName);
            var emp2 = new
            {
                FirstName = "abc",
                Age = 10
            };
            Console.WriteLine(emp2.FirstName+" "+emp2.Age);
        }
    }
}
