﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsLibrary
{
    public abstract class Shapes
    {
        protected float radius;
        protected int side;

        public Shapes(float radius)
        {
            this.radius = radius;


        }
        public Shapes(int side)
        {
            this.side = side;
        }
        public abstract void CalculateArea();
    }  
            public class circle : Shapes
            {
            

            public circle(float radius) : base(radius)
            {

            }

                    public override void CalculateArea()
                {
                    float area = (float)Math.PI * radius * radius;
                    Console.WriteLine("Area of circle is :" + area);
                }
            }
            public class Square : Shapes
            {
           

            public Square(int side) : base(side)
            {

            }

                public override void CalculateArea()
                {
                    int area = side * side;
                    Console.WriteLine("area of square is" + area);
                }
            }
        }
    

