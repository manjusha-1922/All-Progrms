﻿using System;
using StudentLibrary;
namespace StudentMarks
{
    public class StudentMarksExample
    {
        static void Main(string[] args)
        {
            string[] subjects = { "english", "social", "maths" };
            int[] marks = new int[subjects.Length];

            StudentMarks_class stObj = new StudentMarks_class(marks);
            
            for(int i=0;i<subjects.Length;i++)
            {
                Console.WriteLine("\n" + subjects[i]+" : ");
                marks[i] = int.Parse(Console.ReadLine());

            }
            stObj.display(subjects, marks);
            stObj.CalculateTotal(subjects, marks, subjects.Length);

            
        }

    }
}
