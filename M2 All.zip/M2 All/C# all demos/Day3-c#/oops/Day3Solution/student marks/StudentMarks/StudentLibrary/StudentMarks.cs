﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentLibrary
{
    public class StudentMarks_class
    {
        string[] subjects;
        int[] marks;

        public StudentMarks_class(int []marks)
        {
            this.marks = marks;
        }

        public void display(string[] subjects,int[] marks)
        {
            for(int i=0;i<subjects.Length;i++)
            {
                Console.WriteLine("\n" + subjects[i] + ":" + marks[i]);

            }
        }
       
        public void CalculateTotal(string[] subjects,int[] marks,int size)
        {
            int total = 0;
            float percentage;

            for(int i=0;i<size;i++)
            {
                total += marks[i];
            }

            percentage = (float)total / size;

            Console.WriteLine("\nTotal : "+total);
            Console.WriteLine("Percentage : "+percentage);
        }
    }
}
