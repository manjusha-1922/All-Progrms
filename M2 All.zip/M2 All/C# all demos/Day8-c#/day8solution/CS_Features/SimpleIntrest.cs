﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Features
{
    class SimpleIntrest
    {
        /// <summary>
        /// //optional parameters are default arguments
        /// pa is optional parameter
        /// noy and roi are optional parameters
        /// all optional parameters must apper after positional parameters
        /// by using positional and optional parameters
        /// we can reduce no.of over loading functions
        /// </summary>
        /// <param name="pa">accepts principle amount</param>
        /// <param name="noy">accept no.of years</param>
        /// <param name="roi">accepts rate of intrest</param>
        /// <returns></returns>
        public static float Calculate(float pa,float noy=2,float roi=2)
        {
            float si = (pa * roi * noy) / 100;
            return si;
        }
    }
}
