﻿using System;


namespace CS_Features
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("simple intrest is" + SimpleIntrest.Calculate(1000,2,2));

            Console.WriteLine("simple intrest is" + SimpleIntrest.Calculate(1000));

            Console.WriteLine("simple intrest is"+SimpleIntrest.Calculate(10000,roi:11,noy:2));

            Console.WriteLine("simple intrest is" + SimpleIntrest.Calculate(10000, roi:4));

            //it wont work
            //optional parameter must appear after positional parameter
           // Console.WriteLine("simple intrest is" + SimpleIntrest.Calculate(10000,noy:4,7));
        }
    }
}
