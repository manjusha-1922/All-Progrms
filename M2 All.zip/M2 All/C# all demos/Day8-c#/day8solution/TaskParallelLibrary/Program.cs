﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskParallelLibrary
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread t1 = new Thread(RunMillionIterations);
            t1.Start();
            // Parallel.For(0, 1000000, x => RunMillionIterations());

            //1) way of creating task
            //Console.WriteLine("Before calling task1.........");
            //Task task1 = new Task(() => Console.WriteLine("Task1 is started"));
            //task1.Start();
             

            //2) way of creating task
            Task.Factory.StartNew(() =>
            {
                int a = 10, b = 20;
                Console.WriteLine("Addition is " + (a + b));
            });

            //3)way of creating task
            //we can create multiple tasks and we can add to queue using 
            //Run() function
            Task taskA = Task.Run(() =>
              {
                  Console.WriteLine("Hello from task A");
              });

            Console.WriteLine("Current thread name is "+Thread.CurrentThread.Name);
            Thread.CurrentThread.Name = "Main Thread";
            Console.WriteLine("After giving name to main thread..."+Thread.CurrentThread.Name);

            Console.WriteLine("After calling task1.........");

            Console.ReadKey();
        }

        private static void RunMillionIterations()
        {
            string x = "";
            for(int i=0;i<1000000;i++)
            {
                x = x + "s";
            }
        }
    }
}
