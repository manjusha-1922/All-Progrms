﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskParallelLibrary
{
    class AsyncAndAwakeExample
    {
        static void Main(string[] args)
        {
            //var scores = new List<int> { 80, 80, 80, 80, 80, 80 };
            //CalculateTotal(scores);
            //Console.WriteLine("Main Thread..!");
            //Console.ReadKey();

            Method();
            Console.WriteLine("MainThread...!");
            Console.ReadKey();
        }

        private async static void Method()
        {
            //Task.Run(new Action(LongTask));
            await Task.Factory.StartNew(LongTask);
            Console.WriteLine("NewThread....!");
        }

        private static void LongTask()
        {
            Console.WriteLine("Long task started");
            Thread.Sleep(5000);
            Console.WriteLine("Long task completed");
        }

        //private static void CalculateTotal(List<int> scores)
        //{
            
        //}
    }
}
