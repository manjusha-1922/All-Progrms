﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TaskParallelLibrary
{
    class Task_Continuty
    {
        static void Main(string[] args)
        {
            List<int> marks = new List<int> { 80, 80, 80, 80, 80, 80 };
            int total = 0;
            Task.Factory.StartNew(() =>
            {
                foreach (var mark in marks)
                {
                    total += mark;
                }
            }).ContinueWith((x) =>
            {
                float per = total / 6;

                if (per > 70)
                {
                    Console.WriteLine("Total is " + total);
                    Console.WriteLine("Percentage is " + per);
                    Console.WriteLine("U passed in distinction");
                }
            }).ContinueWith((x) =>
            {
                Console.WriteLine("Good work done by u.....");
            });
        }
    }
}
