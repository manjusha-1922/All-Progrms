﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskParallelLibrary
{
    class ParallelFor_ForEach
    {
        static void Main(string[] args)
        {
            var intList = new List<int> { 1, 2, 5, 6, 8, 56, 74, 24, 67, 77, 45, 765 };

            //parallel.ForEach first param is list
            Parallel.ForEach(intList, (i) => Console.WriteLine("\t" + i));

            Console.WriteLine("\nOutput of parallel.For");
            //parallel.For , first param is lower bound,
            //second param is upper bound
            Parallel.For(0, 100, (i) => Console.WriteLine("\t" + i));

            Console.ReadKey();
        }
    }
}
