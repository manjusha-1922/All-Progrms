﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Customer.Entity;

namespace Customer.DataAccessLayer
{

    public class CustomerDAL

    {

        public static List<Customer.Entity.Customer> custList
          = new List<Customer.Entity.Customer>();

        public static void InsertCustomer(Customer.Entity.Customer newCust)

        {


            try
            {

                FileStream fsObj = new FileStream
                  (@"D:\FileIO\customer.txt", FileMode.Create);

                BinaryFormatter binaryObj = new BinaryFormatter();

                custList.Add(newCust);

                binaryObj.Serialize(fsObj, custList);

                fsObj.Close();
            }


            catch (SystemException ex) { throw ex; }
        }



        public static List<Entity.Customer> DisplayCustomer()

        {
            List<Customer.Entity.Customer> custList
              = new List<Customer.Entity.Customer>();

            try
            {
                FileStream fsObj = new FileStream
                (@"D:\FileIO\customer.txt", FileMode.Open);

                BinaryFormatter binaryObj = new BinaryFormatter();

                custList = binaryObj.Deserialize(fsObj)
                  as List<Customer.Entity.Customer>;

                fsObj.Close();
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return custList;
        }
    }
}