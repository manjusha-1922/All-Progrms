﻿using System;


namespace Customer.Entity
{
    /// <summary>
    /// Customer Id - CId
    /// Customer Name - Name
    /// Customer City - City
    /// </summary>

    [Serializable]

    public class Customer
    {
        public int CId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
    }
}

