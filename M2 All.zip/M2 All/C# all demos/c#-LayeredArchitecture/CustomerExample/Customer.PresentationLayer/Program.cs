﻿using Customer.BusinessLogicLayer;
using Customer.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer.PresentationLayer

{

    class Program
    {

        static void Main(string[] args)
        {

            while (true)
            {
                Menu();

                Console.Write("Choice :- ");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        {
                            Accept();
                        }

                        break;

                    case 2:
                        {
                            Display();
                        }

                        break;

                    case 0:

                        Environment.Exit(0);
                        break;
                }

            }
        }

        static void Menu()
        {
            Console.WriteLine("\n\t\tMenu:-");
            Console.WriteLine("\t\t1 - Add Customer");
            Console.WriteLine("\t\t2 - Display Customer");
            Console.WriteLine("\t\t0 - Exit");
        }

        static void Accept()
        {
            Customer.Entity.Customer newCust
              = new Customer.Entity.Customer();

            try
            {
                Console.Write("Cid :- ");

                newCust.CId = int.Parse(Console.ReadLine());

                Console.Write("Name :- ");

                newCust.Name = Console.ReadLine();

                Console.Write("City :- ");

                newCust.City = Console.ReadLine();

                CustomerBL.InsertCustomer(newCust);

                Console.WriteLine("Customer Record Inserted Successfully");
            }

            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Display()
        {

            try

            {
                List<Customer.Entity.Customer> custList

                  = CustomerBL.DisplayCustomer();

                if (custList.Count > 0)
                {

                    foreach (var customer in custList)

                    {
                        Console.WriteLine(customer.Name + "\t" + customer.City);
                    }

                }

                else

                    throw new CustomerException("Customer Records Unavailable");
            }

            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}