﻿using System;


namespace Customer.Exception
{
    /// <summary>
    /// Customer Exception - User Defined Exception For Handling exceptions
    /// </summary>

    public class CustomerException : ApplicationException
    {

        public CustomerException()
        {

        }

        public CustomerException(string message) : base(message)
        {

        }
    }
}