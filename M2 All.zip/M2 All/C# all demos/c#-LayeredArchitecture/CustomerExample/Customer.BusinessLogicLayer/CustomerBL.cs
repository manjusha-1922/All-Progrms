﻿using Customer.DataAccessLayer;
using Customer.Exception;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Customer.BusinessLogicLayer
{

    public class CustomerBL

    {

        public static bool ValidateCustomer
                      (Customer.Entity.Customer newCust)
        {

            StringBuilder message = new StringBuilder();

            bool validCustomer = true;

            try
            {

                if (newCust.CId.ToString() == string.Empty)

                {

                    message.AppendLine("Customer id should be provided");
                    validCustomer = false;

                }

                if (newCust.Name == string.Empty)

                {
                    message.AppendLine("Customer name should be provided");
                    validCustomer = false;
                }

                else if (!Regex.IsMatch(newCust.Name, "^[A-Z][a-z]+"))

                {
                    message.AppendLine("Customer name should start with " +
                      "Capital letter and it " +
                      "should have alphabets only\n");

                    validCustomer = false;

                }

                if (newCust.City == string.Empty)
                {
                    message.AppendLine("City should be provided\n");
                    validCustomer = false;
                }

                else if (newCust.City != "Mumbai" && newCust.City != "Delhi"
                  && newCust.City != "Bangalore" && newCust.City != "Pune")

                {

                    message.AppendLine("Customer city should be either Mumbai, Delhi," +
                      " Bangalore or Pune ");

                    validCustomer = false;

                }

                if (validCustomer == false)

                {
                    throw new CustomerException(message.ToString());
                }
            }

            catch (CustomerException ex)

            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return validCustomer;
        }




        public static void InsertCustomer
                    (Customer.Entity.Customer newCust)
        {

            try
            {
                if (ValidateCustomer(newCust))
                {
                    CustomerDAL.InsertCustomer(newCust);
                }
                else
                    throw new CustomerException("Customer data is invalid");
            }


            catch (CustomerException ex)
            {
                throw ex;
            }


            catch (SystemException ex)
            {
                throw ex;
            }
        }


        public static List<Customer.Entity.Customer> DisplayCustomer()

        {

            List<Customer.Entity.Customer> custList = null;


            try
            {
                custList = CustomerDAL.DisplayCustomer();
            }


            catch (CustomerException ex)
            {
                throw ex;
            }


            catch (SystemException ex)
            {
                throw ex;
            }


            return custList;
        }
    }
}
