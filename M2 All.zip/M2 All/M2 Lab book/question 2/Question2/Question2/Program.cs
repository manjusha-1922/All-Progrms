﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Program
    {
        class SchoolDemo
        {
            int rollNumber;
            string studentName;
            byte age;
            char gender;
            DateTime dateOfBirth;
            string address;
            float percentage;

            public int RollNumber
            {
                get; set;
            }
            public string StudentName
            {
                get; set;
            }
            public byte Age
            {
                get; set;
            }
            public char Gender
            {
                get; set;
            }
            public DateTime DateOfBirth
            {
                get; set;
            }
            public string Address
            {
                get; set;
            }
            public float Percentage
            {
                get; set;
            }
            static void Main(string[] args)
            {

                SchoolDemo schoolDemoObj = new SchoolDemo();
                Console.WriteLine("Enter Roll Number : ");
                schoolDemoObj.RollNumber = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Student Name : ");
                schoolDemoObj.StudentName = Console.ReadLine();

                Console.WriteLine("Enter Age : ");
                schoolDemoObj.Age = byte.Parse(Console.ReadLine());
                Console.WriteLine("Enter Gender : ");
                schoolDemoObj.Gender = char.Parse(Console.ReadLine());
                Console.WriteLine("Enter Date of Birth : ");
                schoolDemoObj.DateOfBirth = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Address : ");
                schoolDemoObj.Address = Console.ReadLine();
                Console.WriteLine("Enter Percentage : ");
                schoolDemoObj.Percentage = float.Parse(Console.ReadLine());

                Console.WriteLine("Data Stored sucessfully...!");



            }
        }
    }
}
