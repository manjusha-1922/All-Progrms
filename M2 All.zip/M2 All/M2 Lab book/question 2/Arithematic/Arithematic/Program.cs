﻿using ArithematicLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ArithematicCalculator
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice;
            Console.WriteLine("1. Addition");
            Console.WriteLine("2. Subtraction");
            Console.WriteLine("3. Multiplication");
            Console.WriteLine("4. Division");
            Console.WriteLine("5. Modulo");
            Console.Write("Enter your choice : ");
            choice = int.Parse(Console.ReadLine());

            Arithematic arithmeticObj = new Arithematic();
            Console.Write("\nEnter Number 1 : ");
            arithmeticObj.A = float.Parse(Console.ReadLine());

            Console.Write("\nEnter Number 2 : ");
            arithmeticObj.B = float.Parse(Console.ReadLine());
            Console.Write("\nResult : ");
            switch (choice)
            {
                case 1:
                    Console.WriteLine(arithmeticObj.Addition());

                    break;

                case 2:
                    Console.WriteLine(arithmeticObj.Subtraction());

                    break;
                case 3:
                    Console.WriteLine(arithmeticObj.Multiplication());

                    break;
                case 5:
                    Console.WriteLine(arithmeticObj.Division());

                    break;
                case 6:
                    Console.WriteLine(arithmeticObj.Modulo());

                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;
            }
        }
    }
}
