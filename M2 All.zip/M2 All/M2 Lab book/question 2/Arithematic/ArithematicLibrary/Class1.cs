﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithematicLibrary
{
    public class Arithematic
    {
        private float a;
        private float b;


        public float A
        {
            get; set;
        }
        public float B
        {
            get; set;
        }

        public float Addition()
        {
            return A + b;
        }
        public float Subtraction()
        {
            return A - b;
        }
        public float Multiplication()
        {
            return A * b;
        }
        public float Division()
        {
            return A / b;
        }
        public int Modulo()
        {

            return (int)A % (int)B;
        }
    }
}
