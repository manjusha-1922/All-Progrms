﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
   abstract public class Employee
    {
        int employeeId;
        string employeeName;
        string address;
        string city;
        string department;
        float salary;

        public Employee()
        { }

        public int EmployeeId
        {
            get; set;
        }
        public string EmployeeName
        {
            get; set;
        }
        public string Address
        {
            get; set;
        }
        public string City
        {
            get; set;
        }
        public string Department
        {
            get; set;
        }
        public float Salary
        {
            get; set;
        }
        virtual public float GetSalary()
        {
            return Salary;
        }
        public void Display()
        {
            Console.WriteLine("---------------------------------------------------------------------------------");
            Console.WriteLine("Employee Id : " + EmployeeId);
            Console.WriteLine("Employee Name : " + EmployeeName);
            Console.WriteLine("Employee Address : " + Address);
            Console.WriteLine("Employee City : " + City);
            Console.WriteLine("Employee Department : " + Department);
            Console.WriteLine("Employee Salary : " + Salary);


        }
    }
    public class ContractEmployee : Employee
    {
        public float perks;
        public float Perks
        {
            get; set;
        }
        public override float GetSalary()
        {
            Console.WriteLine("Enter Perks : ");
            Perks = float.Parse(Console.ReadLine());
            Salary = Salary + Perks;
            return Salary;
        }

    }
    public class PermanentEmployee : Employee
    {
        private float providentFund;

        public float ProvidentFund
        {
            get; set;
        }
        public override float GetSalary()
        {
            Console.WriteLine("Enter Provident Fund : ");
            ProvidentFund = float.Parse(Console.ReadLine());
            Salary = Salary - ProvidentFund;
            return Salary;
        }
    }
}
