﻿using EmployeeLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabBook_M2_Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            int count;

            Console.WriteLine("Enter the number of Employees");
            count = int.Parse(Console.ReadLine());

            Employee[] employeeObj = new Employee[count];

            for (int i = 0; i < count; i++)
            {

                Console.WriteLine("1.Contract Employee");
                Console.WriteLine("2.Permanent Employee");
                Console.WriteLine("Enter choice : ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        employeeObj[i] = new ContractEmployee();
                        break;
                    case 2:
                        employeeObj[i] = new PermanentEmployee();
                        break;



                }
                Console.WriteLine("-------------------------------------------------------------------------------------------------");
                Console.Write("\nEnter Employee Id : ");
                employeeObj[i].EmployeeId = int.Parse(Console.ReadLine());

                Console.Write("\nEnter Employee Name : ");
                employeeObj[i].EmployeeName = Console.ReadLine();


                Console.Write("\nEnter Employee Address : ");
                employeeObj[i].Address = Console.ReadLine();

                Console.Write("\nEnter Employee City : ");
                employeeObj[i].City = Console.ReadLine();

                Console.Write("\nEnter Employee Department : ");
                employeeObj[i].Department = Console.ReadLine();

                Console.Write("\nEnter Employee Salary : ");
                employeeObj[i].Salary = float.Parse(Console.ReadLine());

                employeeObj[i].GetSalary();
                Console.WriteLine("---------------------------------------------------------------------------------------------------");
            }

            Console.WriteLine("Displaying Details");
            for (int i = 0; i < count; i++)
            {
                employeeObj[i].Display();
            }
        }
    }
}
