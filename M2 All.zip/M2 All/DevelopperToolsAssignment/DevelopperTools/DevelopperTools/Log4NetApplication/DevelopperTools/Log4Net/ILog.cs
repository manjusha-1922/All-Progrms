﻿namespace Log4Net
{
    internal interface ILog
    {
        void DebugFormat(string v, int counter);
    }
}