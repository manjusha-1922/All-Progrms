﻿using log4net;
using log4net.Config;
using System;

namespace Log4NetDemo
{
    public class Program
    {
        
private static readonly ILog log =
LogManager.GetLogger("ConsoleLogger");
        static void Main(string[] args)
        {
            //This calls the default configurator for log4net
            XmlConfigurator.Configure();
            log.Info("Entering application.");
            for (int counter = 1; counter <= 10; counter++)
            {
                log.DebugFormat("Inside of the loop (Counter = {0})", counter);
            }
            try
            {
                throw new NotImplementedException("Testing log4net");
            }
            catch (NotImplementedException ex)
            {
                log.Fatal(ex.Message);
            }
            log.Info("Exiting application.");
        }
    }
}