﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestDemo1;

namespace OneATestLibrary
{
    [TestFixture]
    public class MyStackTest
    {
        MyStackClass myStackObj = new MyStackClass();
        [SetUp]
        public void Init()
        {

        }
        [Test]
        public void CheckPop()
        {
            object ob1 = new object();
            myStackObj.Push(ob1);
            object obj = myStackObj.Pop();
            Assert.AreEqual(ob1, obj);
        }
        [Test]
        public void CheckPush()
        {
            object ob1 = new object();
            myStackObj.Push(ob1);
            object obj = myStackObj.Top();
            Assert.AreEqual(ob1, obj);
        }
    }

}
