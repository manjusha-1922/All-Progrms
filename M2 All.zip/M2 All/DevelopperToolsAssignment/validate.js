function validate(){
	var uname = document.frmRegister.name.value;
	//alert("Thanks "+User Name+" for registration.");
	var uid = document.frmRegister.id.value;
	var uname= document.frmRegister.name.value;
	var uemail = document.frmRegister.email.value;
	var uphone= document.frmRegister.phone.value;
    var umeter= document.frmRegister.meter.value;
    var ucharges= document.frmRegister.charges.value;
	var val=umeter*ucharges;
	var win = window.open();
	var newDocument = win.document;
	newDocument.write("<h1>Electricity Bill</h2>");
	newDocument.write("<h1>user Id:</h1>"+uid);
	newDocument.write("<h1>User Name :</h1>"+uname);
	newDocument.write("<h1>Email Id:</h1>"+uemail);
	newDocument.write("<h1>Phone No:</h1>"+uphone);
      newDocument.write("<h1>Meter Readings:</h1>"+umeter);
        newDocument.write("<h1>Charges:</h1>"+ucharges);
		newDocument.write("<h1>value:</h1>"+val);
}