﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Textbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_MouseMove(object sender, MouseEventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            TextBox t = sender as TextBox;
            t.BackColor = Color.Yellow;
            t.ForeColor = Color.OrangeRed;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            TextBox t = sender as TextBox;
            t.BackColor = SystemColors.Control;
            t.ForeColor = Color.Black;
        }
    }
}
