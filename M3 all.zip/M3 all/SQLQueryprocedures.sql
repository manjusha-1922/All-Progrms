use [16MayCHN]

select * from Department_Master;

insert into Department_Master values(100,'Home Science');

use Training

-- stored procedures

CREATE PROC usp_retrivestudents_150930
as
begin
select * from Student_master
end

--executing stored procedure

EXEC usp_retrivestudents_150930

--stored procedure with parameters

create proc usp_SearchStudent_150930
(
    @StudCode INT
)
as
begin
    select * from Student_master
	where Stud_Code = @StudCode
end

Exec usp_SearchStudent_150930 1001

--change defnition of stored procedures 

alter proc usp_SearchStudent_150930
(
    @StudCode INT
)
as
begin
select Stud_Code,Stud_Name from Student_master
where Stud_code=@StudCode
end

Exec usp_SearchStudent_150930 1001

exec usp_SearchStudent_150930 1001 with RESULT sets
((StudentCode int,
StudentName varchar(20),
DepartmentCode int));

--using out parameter

create proc usp_CountStudAsPerCity_150930
(
   @city  varchar(20),
   @count  int out
)
as
begin
   select @count=count(Stud_Code)
   from Student_master
   where address = @city
end
declare @StudentCount int

exec usp_CountStudAsPerCity_150930 'chennai' , @StudentCount out
print @StudentCount


--exceptions

declare @v_Stud_Code int
declare @v_Stud_Name varchar(30) 
declare @v_Dept_Code int
declare @errorcode int


set @v_Stud_Code=1001
set @v_Stud_Name='Mehul'
set @v_Dept_Code=10


insert into Student_master values(1001,'Mehul',10)

	  set @errorcode = @@error
	  if(errorcode > 0)
	  begin
	  print 'ERROR'
	  end
	  else
	  print 'Added successfully'
