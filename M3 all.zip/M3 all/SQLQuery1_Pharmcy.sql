﻿create table manju.Employee_df_150930
(
  Id int PRIMARY KEY,
  Name varchar(20),
  Age int
)

select * from Employee_mf_150930
drop table dbo.[__MigrationHistory]