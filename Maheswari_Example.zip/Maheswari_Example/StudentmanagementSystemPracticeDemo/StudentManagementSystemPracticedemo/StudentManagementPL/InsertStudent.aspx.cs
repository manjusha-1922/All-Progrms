﻿using StudentExceptions;
using StudentManagementBAL;
using StudentPL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManagementPL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

          
            if (!Page.IsPostBack)
            {
                string currentDate = DateTime.Today.ToShortDateString();
                //Assign the value to compare here
                cmpdob.ValueToCompare = currentDate;
                BindContrydropdown();
            }
            try

            {
                txtStudCode.Text = StudentValidations.GetStud_code().ToString();

                if (Session["user"] == null)
                {
                    Response.Redirect("Login.aspx");
                }

                Master.Logout = true;
                Master.Menu = true;

            }
            catch(Exception ex)
            {
                throw ex;
            }
         
        }
        protected void BindContrydropdown()
        {
            //conenction path for database
            
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn2"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Dept_code,Dept_Name FROM [maheswari].[M4_150938_Department]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                ddlcode.DataSource = ds;
                ddlcode.DataTextField = "Dept_code";
                ddlcode.DataValueField = "Dept_code";
                ddlcode.DataBind();
                ddlcode.Items.Insert(0, new ListItem("--Select--", "0"));
                con.Close();
            }
        }
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                
                Student stud = new Student();
                //txtStudCode.Text = StudentValidations.GetStud_code().ToString();
                //stud.Stud_Code = Convert.ToInt32(txtStudCode.Text);
                stud.Stud_Name = txtStudName.Text;
                stud.Dept_Code = Convert.ToInt32(ddlcode.Text);
                stud.Stud_Dob = Convert.ToDateTime(txtDOB.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentValidations.insertStudent(stud);

                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Inserted Successfully');</script>");
                }
                else
                {
                    throw new StudentException("Student record not inserted");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}