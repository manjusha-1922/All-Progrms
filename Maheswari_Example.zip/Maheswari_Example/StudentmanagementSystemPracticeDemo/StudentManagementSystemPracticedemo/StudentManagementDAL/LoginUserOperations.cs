﻿using StudentPL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementDAL
{
    public class LoginUserOperations
    {
        public static string ValidateLogin(LoginUser user)
        {
            string userName = "";

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[maheswari].[SPX_ValidateLogin_M4_150938_LoginUser]";

                cmd.Parameters.AddWithValue("@username", user.UserName);
                cmd.Parameters.AddWithValue("@password", user.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    userName = dr["UserName"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }
    }
}
