﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AutoPostBackDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlCity.Items.Add("Chennai");
                ddlCity.Items.Add("Bangalore");
                ddlCity.Items.Add("Hyderabad");
                ddlCity.Items.Add("Mumbai");
                ddlCity.Items.Add("Pune");
                ddlCity.Items.Add("Other");
            }
        }

        protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCity.SelectedItem.Text == "Other")
            {
                divOther.Visible = true;
            }
            else
            {
                divOther.Visible = false;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            ddlCity.Items.Insert(ddlCity.Items.Count - 1, txtOther.Text);
            divOther.Visible = false;
        }
    }
}