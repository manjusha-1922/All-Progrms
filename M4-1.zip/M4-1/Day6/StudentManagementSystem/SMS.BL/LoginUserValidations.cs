﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BL
{
    public class LoginUserValidations
    {
        public static string ValidateLogin(LoginUser user)
        {
            string userName = "";

            try 
            {
                userName = LoginUserOperations.ValidateLogin(user);
            }
            catch (LoginUserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }
    }
}
