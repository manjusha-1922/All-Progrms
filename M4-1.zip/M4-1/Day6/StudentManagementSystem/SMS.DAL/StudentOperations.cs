﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;
using SMS.Exception;

namespace SMS.DAL
{
    public class StudentOperations
    {
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_InsertStudent_115022";

                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@sname", stud.StudName);
                cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
                cmd.Parameters.AddWithValue("@dob", stud.DOB);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_UpdateStudent_115022";

                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DeleteStudent_115022";

                cmd.Parameters.AddWithValue("@scode", studCode);
                
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Student SearchStudent(int studCode)
        {
            Student stud = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_SearchStudent_115022";

                cmd.Parameters.AddWithValue("@scode", studCode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    stud = new Student();
                    stud.StudCode = Convert.ToInt32(dr["Stud_Code"]);
                    stud.StudName = dr["Stud_Name"].ToString();
                    stud.DeptCode = Convert.ToInt32(dr["Dept_Code"]);
                    stud.DOB = Convert.ToDateTime(dr["Stud_Dob"]);
                    stud.Address = dr["Address"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student> DisplayStudents()
        {
            List<Student> studList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayStudents_115022";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<Student>();
                    while (dr.Read())
                    {
                        Student stud = new Student();
                        stud.StudCode = Convert.ToInt32(dr["Stud_Code"]);
                        stud.StudName = dr["Stud_Name"].ToString();
                        stud.DeptCode = Convert.ToInt32(dr["Dept_Code"]);
                        stud.DOB = Convert.ToDateTime(dr["Stud_Dob"]);
                        stud.Address = dr["Address"].ToString();

                        studList.Add(stud);
                    }
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
