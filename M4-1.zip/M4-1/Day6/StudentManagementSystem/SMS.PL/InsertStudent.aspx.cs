﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.PL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try 
            {
                Student stud = new Student();
                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtStudName.Text;
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtDOB.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = StudentValidation.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Student Record Inserted Successfully');</script>");
                }
                else
                {
                    throw new StudentException("Student record not inserted");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}