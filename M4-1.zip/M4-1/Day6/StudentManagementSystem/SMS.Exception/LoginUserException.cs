﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exception
{
    public class LoginUserException : ApplicationException
    {
        public LoginUserException()
            : base()
        { }

        public LoginUserException(string message)
            : base(message)
        { }
    }
}
