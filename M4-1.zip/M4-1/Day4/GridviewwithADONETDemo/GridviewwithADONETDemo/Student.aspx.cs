﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace GridviewwithADONETDemo
{
    public partial class Student : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_14Mar18_Pune;uid=sqluser;pwd=sqluser");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Student_master", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Stud");

            gvStudent.DataSource = ds.Tables["Stud"];
            gvStudent.DataBind();
        }
    }
}