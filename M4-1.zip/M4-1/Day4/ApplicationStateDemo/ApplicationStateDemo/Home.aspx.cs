﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ApplicationStateDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblSessionID.Text = Session.SessionID;
            lblSessionCount.Text = Session["counter"].ToString();
            lblApplicationCounter.Text = Application["counter"].ToString();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int sessionCnt = (int)Session["counter"];
            sessionCnt = sessionCnt + 1;
            Session["counter"] = sessionCnt;
            lblSessionCount.Text = Session["counter"].ToString();

            int appCnt = (int)Application["counter"];
            appCnt = appCnt + 1;
            Application["counter"] = appCnt;
            lblApplicationCounter.Text = Application["counter"].ToString();
        }
    }
}