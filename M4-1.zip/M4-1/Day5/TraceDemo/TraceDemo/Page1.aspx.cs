﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TraceDemo
{
    public partial class Page1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            HttpCookie ck = new HttpCookie("emp");
            ck.Values.Add("id", txtID.Text);
            ck.Values.Add("name", txtName.Text);
            Response.Cookies.Add(ck);

            Response.Redirect("Page2.aspx?id=" + txtID.Text + "&name=" + txtName.Text);

        }
    }
}