﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebuggingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, result;

            Console.Write("Enter number 1 : ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter number 2 : ");
            num2 = Convert.ToInt32(Console.ReadLine());

            result = num1 + num2;

            Console.WriteLine("{0} + {1} => {2}", num1, num2, result);

            Console.WriteLine("\nLoop Start");
            for (int i = 0; i < 25; i++)
            {
                Console.WriteLine("Showing Index : " + i);
            }
            Console.WriteLine("Loop Ends");
            
            Console.WriteLine("Calling Method.....");
            PopulateData();
            Console.WriteLine("Method Call End!!!!");

            Console.ReadKey();
        }

        public static void PopulateData()
        {
            List<String> cities = new List<string>();
            cities.Add("Bangalore");
            cities.Add("Chennai");
            cities.Add("Gandhi Nagar");
            cities.Add("Hyderabad");
            cities.Add("Kolkatta");
            cities.Add("Mumbai");
            cities.Add("Noida");
            cities.Add("Pune");
        }
    }
}
