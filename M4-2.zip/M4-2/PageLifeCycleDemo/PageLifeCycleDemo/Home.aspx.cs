﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PageLifeCycleDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_LoadPostData(object sender, EventArgs e)
        {
            Response.Write("Page LoadPostData Event Occured.<br/>");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("Page Load Event Occured.<br/>");
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            Response.Write("Page PreRender Event Occured.<br/>");
        }

        protected void Page_Render(object sender, EventArgs e)
        {
            Response.Write("Page Render Event Occured.<br/>");
        }

        protected void Page_Unload(object sender, EventArgs e)
        {
            //Response.Write("Page Unload Event Occured.<br/>");
        }

        protected void Page_SaveViewState(object sender, EventArgs e)
        {
            Response.Write("Page SaveViewState Event Occured.<br/>");
        }

        protected void Page_PreLoad(object sender, EventArgs e)
        {
            Response.Write("Page PreLoad Event Occured.<br/>");
        }

        protected void Page_LoadViewState(object sender, EventArgs e)
        {
            Response.Write("Page LoadViewState Event Occured.<br/>");
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            Response.Write("Page Init Event Occured.<br/>");
        }

        protected void Page_PreInit(object sender, EventArgs e)
        {
            Response.Write("Page PreInit Event Occured.<br/>");
        }
    }
}